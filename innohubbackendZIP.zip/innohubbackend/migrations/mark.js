/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
    return knex.schema
        .createTable('student_marks', function (table) {
            table.increments('id').primary();
            table.integer('student_id').unsigned().nullable();
            table.integer('test_score').notNullable();
            table.integer('interview_score').notNullable;
            table.foreign('student_id').references('student_enrollment.student_id');
        })
        .createTable('qualified_students', function (table) {
            table.string('roll_no', 45).primary();
            table.integer('student_id').unsigned().nullable();
            table.integer('test_score').notNullable();
            table.integer('interview_score').notNullable();
            table.foreign('student_id').references('student_marks.student_id');
            table.string('installment1',30).notNullable().defaultTo('default_value1');;
            table.string('installment2',30).notNullable().defaultTo('default_value2');;
            table.timestamp('date').notNullable().defaultTo(knex.fn.now());
            table.tinyint('status').defaultTo(0);
        });
        
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function (knex) {
    return knex.schema
        .dropTableIfExists('student_marks')
        .dropTableIfExists('qualified_students');
};
