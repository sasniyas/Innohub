/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
    return knex.schema
        .createTable('states', function (table) {
            table.increments('state_id').primary();
            table.string('state_name', 255).notNullable();
            table.date('creation_date');
            table.tinyint('status').defaultTo(0);
        })
        .createTable('cities', function (table) {
            table.increments('city_id').primary();
            table.string('city_name', 255);
            table.integer('state_id').unsigned();
            table.foreign('state_id').references('states.state_id');
            table.string('state_name', 255);
            table.date('creation_date');
            table.tinyint('status').defaultTo(0);
        })
        .createTable('higher_education', function (table) {
            table.increments('degree_id').primary();
            table.string('degree_name', 255).notNullable();
            table.date('creation_date');
            table.tinyint('status').defaultTo(0);
        });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function (knex) {
    return knex.schema
        .dropTableIfExists('cities')
        .dropTableIfExists('states')
        .dropTableIfExists('higher_education');
};
