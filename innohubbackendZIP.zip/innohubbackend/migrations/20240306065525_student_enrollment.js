/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.createTable('student_enrollment', function(table) {
      table.increments('student_id').primary();
      table.string('first_name').notNullable();
      table.string('last_name').notNullable();
      table.date('dob').notNullable();
      table.text('address_line1').notNullable();
      table.text('address_line2');
      table.string('email_id').notNullable();
      table.string('adhaar_no', 12).notNullable();
      table.string('mobile_no', 15).notNullable();
      table.string('gender').notNullable();
      table.string('state').notNullable();
      table.string('city').notNullable();
      table.string('pincode', 10).notNullable();
      table.binary('upload_photo');
      table.string('higher_education');
      table.decimal('marks_obtained', 5, 2);
      table.integer('year_of_completion');
      table.string('specialization');
      table.string('university');
      table.string('HSC');
      table.decimal('HSC_marks', 5, 2);
      table.integer('HSC_completion_yr');
      table.string('SSC');
      table.decimal('SSC_marks', 5, 2);
      table.integer('SSC_completion_yr');
      table.text('achievements');
      table.binary('upload_resume');
      table.timestamp('created_at').defaultTo(knex.fn.now());
      table.timestamp('updated_at').defaultTo(knex.fn.now());
      table.tinyint('status').defaultTo(0);
    });
  };

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function (knex) {
    return knex.schema
        .dropTableIfExists('student_enrollment')
  
};
