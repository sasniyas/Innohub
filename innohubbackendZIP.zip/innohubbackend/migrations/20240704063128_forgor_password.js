exports.up = async function (knex) {
  const exists = await knex.schema.hasTable('forgot_password');
  if (!exists) {
    return knex.schema.createTable('forgot_password', function (table) {
      table.increments('id').primary();
      table.string('email_id').notNullable();
      table.string('otp', 255).nullable();
      table.dateTime('otpexpiry').nullable();
      table.string('token', 255).nullable();
      table.timestamps(true, true);
      table.foreign('email_id').references('email_id').inTable('user_credentials');
    });
  }
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('forgot_password');
};