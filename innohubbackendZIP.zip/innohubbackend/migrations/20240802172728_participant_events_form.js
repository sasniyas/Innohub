/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.createTable('participants', function(table) {
      table.increments('id').primary();
      table.string('firstName').notNullable();
      table.string('lastName').notNullable();
      table.string('email').notNullable().unique();
      table.string('mobile').notNullable();
      table.string('profession').notNullable();
      table.string('country').notNullable();
      table.string('payment').notNullable(); // 'Paid' or 'Free'
      table.string('event').notNullable(); // 'Webinar', 'Conference', 'Workshop'
      table.string('heardFrom').nullable(); // Can be null if 'Others' is specified
      table.string('otherSource').nullable(); // For additional info if 'Others' is chosen

      table.timestamp('created_at').defaultTo(knex.fn.now());
      table.timestamp('updated_at').defaultTo(knex.fn.now());
    });
  };
  
  /**
   * @param { import("knex").Knex } knex
   * @returns { Promise<void> }
   */
  exports.down = function(knex) {
    return knex.schema.dropTableIfExists('participants');
  };
  