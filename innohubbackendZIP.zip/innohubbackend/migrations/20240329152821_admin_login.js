/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = async function(knex) {
    await knex.schema.createTable('roles', function (table) {
        table.increments('roles_id').primary();
        table.string('roles_name', 255).notNullable();
        table.unique('roles_name');
        table.date('creation_date');
        table.tinyint('status').defaultTo(0);
    });
  
    // await knex.schema.createTable('user', function (table) {
    //     table.increments('user_id').primary();
    //     table.string('username', 255).notNullable();
    //     table.string('password', 255).defaultTo(null);
    //     table.string('email', 255).notNullable();
    //     table.string('phone_number', 20);
    //     table.integer('roles_id').unsigned();
    //     table.date('start_date');
    //     table.timestamp('modify_date').defaultTo(knex.fn.now());
    //     table.foreign('roles_id').references('roles.roles_id');
    //     table.enum('status', ['Registered', 'Indiscussion', 'Joined', 'Rejected', 'Staff']).defaultTo('Indiscussion');
    //     table.boolean('isActive').defaultTo(true);
    // });
  
    /*await knex('roles').insert([
        { roles_name: 'admin' },
        { roles_name: 'HR' },
        { roles_name: 'student' }
    ]);*/

    await knex.schema.createTable('super_admin_login', (table) => {
        table.increments('id').primary();
        table.string('username', 255).notNullable();
        table.string('password', 255).notNullable();
    });

    await knex.schema.createTable('enrollments', (table) => {
        table.increments('enrollment_id').primary();
        table.string('first_name', 50).notNullable();
        table.string('email_id', 255).notNullable();
        table.string('mobile_no', 20);
        table.integer('student_id').unsigned();
        table.foreign('student_id').references('student_enrollment.student_id');
    });

    
};

exports.down = async function(knex) {
    // await knex.schema.dropTableIfExists('user');
    await knex.schema.dropTableIfExists('roles');
    await knex.schema.dropTableIfExists('adminLogin');
    await knex.schema.dropTableIfExists('enrollments');
};