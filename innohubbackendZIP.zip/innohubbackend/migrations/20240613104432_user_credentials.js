exports.up = function(knex) {
    return knex.schema
      .createTable('User_management_details', function(table) {
        table.increments('user_id').primary();
        table.string('first_name').notNullable();
        table.string('last_name').notNullable();
        table.string('adhaar_no', 12).notNullable();
        table.string('email_id').notNullable();
        table.string('Communication_Address_line_1', 150).notNullable();
        table.date('dob').notNullable();
        table.string('city').notNullable();
        table.string('mobile_no', 15).notNullable();
        table.string('pincode', 10).notNullable();
        table.string('gender').notNullable();
        table.string('state').notNullable();
        table.string('roles_name', 255).notNullable();
        table.string('profession', 255).notNullable();
        table.timestamp('created_at').defaultTo(knex.fn.now());
        table.timestamp('updated_at').defaultTo(knex.fn.now());
        // table.tinyint('status').defaultTo(0);

  
        // Add indexes
        table.index('email_id');
        table.index('roles_name');
      })
      .createTable('user_credentials', function(table) {
        table.increments('id').primary();
        table.string('username').notNullable();
        table.string('password').notNullable();
        table.string('roles_name', 255).notNullable();
        table.string('email_id').notNullable();
        table.timestamps(true, true); // To add created_at and updated_at columns
  
        // Add foreign key constraints
        table.foreign('roles_name').references('roles_name').inTable('User_management_details');
        table.foreign('email_id').references('email_id').inTable('User_management_details');
      });
  };
  
  exports.down = function(knex) {
    return knex.schema
      .dropTableIfExists('user_credentials')
      .dropTableIfExists('User_management_details');
  };
  