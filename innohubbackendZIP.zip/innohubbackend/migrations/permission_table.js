exports.up = async function (knex) {
  const exists = await knex.schema.hasTable('permission_table');
  if (!exists) {
    return knex.schema.createTable('permission_table', function (table) {
      table.increments('permission_id').primary(); // Unique ID for each permission
      table.string('permission_name').notNullable().unique(); // Unique permission name
      table.string('access_level'); // Access level can be null initially
    });
  }
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('permission_table');
};
