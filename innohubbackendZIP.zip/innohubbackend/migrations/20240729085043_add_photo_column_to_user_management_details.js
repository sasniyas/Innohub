exports.up = function(knex) {
    return knex.schema.table('User_management_details', function(table) {
      table.string('photo').nullable(); // Add the photo column
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.table('User_management_details', function(table) {
      table.dropColumn('photo'); // Remove the photo column if rolled back
    });
  };
  