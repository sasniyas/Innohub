exports.up = async function (knex) {
  const exists = await knex.schema.hasTable('roles_permissions');
  if (!exists) {
    return knex.schema.createTable('roles_permissions', function (table) {
      table.increments('id').primary(); // Unique ID for each role_permission entry
      table.integer('roles_id').unsigned().notNullable() // FK for roles
      table.integer('permission_id').unsigned().notNullable() // FK for permissions
      table.foreign('roles_id').references('roles_id').inTable('roles');
      table.foreign('permission_id').references('permission_id').inTable('permission_table');

    });
  }
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('roles_permissions');
};
