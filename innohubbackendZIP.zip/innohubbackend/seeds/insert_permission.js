
exports.seed = function (knex) {
    // Deletes ALL existing entries
    return knex('permission_table').del()
      .then(function () {
        // Inserts seed entries
        return knex('permission_table').insert([
          { permission_id: 1, permission_name: 'admin_dashboard_add', access_level: true },
          {  permission_id: 2, permission_name: 'admin_dashboard_edit', access_level: true },
          {  permission_id: 3, permission_name: 'admin_dashboard_view', access_level: true},
          {  permission_id: 4, permission_name: 'admin_dashboard_delete', access_level: true},
          {  permission_id: 5, permission_name: 'user_management_add', access_level: true },
          {  permission_id: 6, permission_name: 'user_management_edit', access_level: true},
          {  permission_id: 7, permission_name: 'user_management_view', access_level: true },
          {  permission_id: 8, permission_name: 'user_management_delete', access_level: false },
          {  permission_id: 9, permission_name: 'role_management_add', access_level: true },
          {  permission_id: 10, permission_name: 'role_management_edit', access_level: true },
          {  permission_id: 11, permission_name: 'role_management_view', access_level: true},
          {  permission_id: 12, permission_name: 'role_management_delete', access_level: true},
          {  permission_id: 13, permission_name: 'master_module_add', access_level: true},
          {  permission_id: 14, permission_name: 'master_module_edit', access_level: true },
          {  permission_id: 15, permission_name: 'master_module_view', access_level: true },
          {  permission_id: 16, permission_name: 'master_module_delete', access_level:true },
          {  permission_id: 17, permission_name: 'event_management_add', access_level: true },
          {  permission_id: 18, permission_name: 'event_management_edit', access_level: true },
          {  permission_id: 19, permission_name: 'event_management_view', access_level: true},
          {  permission_id: 20, permission_name: 'event_management_delete', access_level: true },
          {  permission_id: 21, permission_name: 'student_management_add', access_level: true},
          {  permission_id: 22, permission_name: 'student_management_edit', access_level: true},
          {  permission_id: 23, permission_name: 'student_management_view', access_level: true },
          {  permission_id: 24, permission_name: 'student_management_delete', access_level: true },
          // Add more permissions as needed
        ]);
      });
  };
  