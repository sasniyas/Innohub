/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> } 
 */
exports.seed = function(knex) {
  return knex('higher_education')
  
  .then(function () {
    return knex('higher_education').insert([
      { degree_id: 1, degree_name: 'B.A' },
  { degree_id: 2, degree_name: 'B.SC' },
  { degree_id: 3, degree_name: 'B.COM' },
  { degree_id: 4, degree_name: 'B.ED' },
  { degree_id: 5, degree_name: 'B.E' },
  { degree_id: 6, degree_name: 'B. Tech' },
  { degree_id: 7, degree_name: 'B.CA' },
  { degree_id: 8, degree_name: 'M.A' },
  { degree_id: 9, degree_name: 'M.SC' },
  { degree_id: 10, degree_name: 'M.COM' },
  { degree_id: 11, degree_name: 'M.ED' },
  { degree_id: 12, degree_name: 'M.Tech' },
  { degree_id: 13, degree_name: 'MCA' },
  { degree_id: 14, degree_name: 'MBA' },
  { degree_id: 15, degree_name: 'PG' },
  { degree_id: 16, degree_name: 'PHD' }
          
  ]);
});
};
