const db = require('../config/dbConfig');

class City {
  static async getByState(stateId) {
    try {
      const [results] = await db.query('SELECT * FROM cities WHERE state_id = ?', [stateId]);
      return results;
    } catch (error) {
      console.error('Error fetching cities by state:', error);
      throw error;
    }
  }
}

module.exports = City;
