const bcrypt = require('bcrypt');
const db = require('../config/dbConfig');

class SuperAdminLogin {
    static async create(username, password) {
        try {
            // Hash the password
            const hashedPassword = await bcrypt.hash(password, 10);

            const sql = 'INSERT INTO super_admin_login (username, password) VALUES (?, ?)';
            const values = [username, hashedPassword];

            // Use db for database operations instead of connection
            await db.promise().query(sql, values);

            return { message: 'Super admin created successfully' };
        } catch (error) {
            console.error('Error creating super admin: ' + error.message);
            throw error;
        }
    }

    static async getByUsernameAndPassword(username, password) {
        try {
            console.log('Fetching admin data for username:', username);

            // Fetch admin data from the database
            const [rows] = await db.promise().query('SELECT * FROM super_admin_login WHERE username = ?', [username]);

            console.log('Fetched rows:', rows);

            if (rows.length === 0) {
                console.log('No admin found with the provided username:', username);
                return null; // No admin found with the provided username
            }

            const admin = rows[0];

            // Compare the provided password with the hashed password in the database
            const isMatch = await bcrypt.compare(password, admin.password);

            if (isMatch) {
                // Password matches, return the admin data
                const { password: _, ...adminWithoutPassword } = admin;
                return adminWithoutPassword;
            } else {
                console.log('Password does not match for username:', username);
                return null; // Password doesn't match
            }
        } catch (error) {
            console.error('Error getting admin by username:', error);
            throw error;
        }
    }
}

module.exports = SuperAdminLogin;
