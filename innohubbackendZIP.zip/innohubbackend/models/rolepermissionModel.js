// const db = require('../config/dbConfig');

// class RolePermission {
//   // Get all role-permission mappings
//   static async getAll() {
//     return db('roles_permissions').select('*');
//   }

//   // Get a specific role-permission mapping by ID
//   static async getById(id) {
//     return db('roles_permissions').where({ id }).first();
//   }

//   // Create a new role-permission mapping
//   static async create(rolePermissionData) {
//     const [id] = await db('roles_permissions').insert(rolePermissionData);
//     return id;
//   }

//   // Delete a role-permission mapping
//   static async delete(role_id, permission_id) {
//     return db('roles_permissions')
//       .where({ roles_id: role_id, permission_id })
//       .del();
//   }

//   // Get permissions for a specific role
//   static async getPermissionsByRoleId(role_id) {
//     return db('roles_permissions')
//       .join('permission_table', 'roles_permissions.permission_id', 'permission_table.permission_id')
//       .where({ roles_id: role_id })
//       .select('permission_table.*');
//   }

//   // Get roles for a specific permission
//   static async getRolesByPermissionId(permission_id) {
//     return db('roles_permissions')
//       .join('roles', 'roles_permissions.roles_id', 'roles.roles_id')
//       .where({ permission_id })
//       .select('roles.*');
//   }
// }

// module.exports = RolePermission;

const db = require('../config/dbConfig');

class RolePermission {
  // Get all role-permission mappings
  static async getAll() {
    try {
      const [results] = await db.query('SELECT * FROM roles_permissions');
      return results;
    } catch (error) {
      console.error('Error fetching role-permission mappings:', error);
      throw error;
    }
  }

  // Get a specific role-permission mapping by ID
  static async getById(id) {
    try {
      const [results] = await db.query('SELECT * FROM roles_permissions WHERE id = ?', [id]);
      return results[0]; // Return the first result
    } catch (error) {
      console.error('Error fetching role-permission mapping by ID:', error);
      throw error;
    }
  }

  // Create a new role-permission mapping
  // static async create(rolePermissionData) {
  //   try {
  //     const [id] = await db.query('INSERT INTO roles_permissions SET ?', rolePermissionData);
  //     return id;
  //   } catch (error) {
  //     console.error('Error creating role-permission mapping:', error);
  //     throw error;
  //   }
  // }

  // Create a new role-permission mapping with validation
static async create(rolePermissionData) {
  if (!rolePermissionData.roles_id || !rolePermissionData.permission_id) {
    throw new Error('Both roles_id and permission_id are required');
  }
  try {
    const [id] = await db.query('INSERT INTO roles_permissions SET ?', rolePermissionData);
    return id;
  } catch (error) {
    console.error('Error creating role-permission mapping:', error);
    throw error;
  }
}


  // Delete a role-permission mapping
  static async delete(role_id, permission_id) {
    try {
      await db.query('DELETE FROM roles_permissions WHERE roles_id = ? AND permission_id = ?', [role_id, permission_id]);
    } catch (error) {
      console.error('Error deleting role-permission mapping:', error);
      throw error;
    }
  }

  // Get permissions for a specific role
  static async getPermissionsByRoleId(role_id) {
    try {
      const [results] = await db.query(`
        SELECT permission_table.* 
        FROM roles_permissions
        JOIN permission_table ON roles_permissions.permission_id = permission_table.permission_id
        WHERE roles_id = ?`, [role_id]);
      return results;
    } catch (error) {
      console.error('Error fetching permissions by role ID:', error);
      throw error;
    }
  }

  // Get roles for a specific permission
  static async getRolesByPermissionId(permission_id) {
    try {
      const [results] = await db.query(`
        SELECT roles.* 
        FROM roles_permissions
        JOIN roles ON roles_permissions.roles_id = roles.roles_id
        WHERE permission_id = ?`, [permission_id]);
      return results;
    } catch (error) {
      console.error('Error fetching roles by permission ID:', error);
      throw error;
    }
  }
}

module.exports = RolePermission;
