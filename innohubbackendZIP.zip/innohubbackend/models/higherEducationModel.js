const db = require('../config/dbConfig');

class Degree {
  static async getAll() {
    try {
      const [results] = await db.query('SELECT * FROM higher_education');
      return results;
    } catch (error) {
      console.error('Error fetching degrees:', error);
      throw error;
    }
  }
}

module.exports = Degree;
