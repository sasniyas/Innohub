const db = require('../config/dbConfig');

const Event = {
  async create(eventData) {
    let {
      eventName, eventPlatform, topic, email, organizerContactNumber,
      eventWebsiteUrl, dateOfEvent, lastDateOfRegistration, selectEvent,
      speakerName, organizer, address, freePaid, paidAmount, aboutEvent, speakerDetails, joiningLink, joiningTime, meetingId, passcode
    } = eventData;
  
    // If the event is free, set paidAmount to NULL or 0
    if (freePaid === 'Free') {
      paidAmount = null;
    }
  
    const query = `
      INSERT INTO events (
        eventName, eventPlatform, topic, email, organizerContactNumber,
        eventWebsiteUrl, dateOfEvent, lastDateOfRegistration, selectEvent,
        speakerName, organizer, address, freePaid, paidAmount, aboutEvent, speakerDetails, joiningLink, joiningTime, meetingId, passcode
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
  
    try {
      const [results] = await db.query(query, [
        eventName, eventPlatform, topic, email, organizerContactNumber,
        eventWebsiteUrl, dateOfEvent, lastDateOfRegistration, selectEvent,
        speakerName, organizer, address, freePaid, paidAmount, aboutEvent, speakerDetails, joiningLink, joiningTime, meetingId, passcode
      ]);
  
      const eventId = results.insertId;
      return eventId;
    } catch (error) {
      console.error('Error creating event:', error);
      throw error;
    }
  },

  async findAll() {
    try {
      const query = 'SELECT * FROM events';
      const [results] = await db.query(query);
      return results;
    } catch (error) {
      console.error('Error fetching events:', error);
      throw error;
    }
  },

  async findById(eventId) {
    try {
      const query = 'SELECT * FROM events WHERE id = ?';
      const [results] = await db.query(query, [eventId]);

      if (results.length === 0) {
        return null; // No event found
      }

      return results[0];
    } catch (error) {
      console.error('Error fetching event by id:', error);
      throw error;
    }
  },

  async updateById(eventId, eventData) {
    try {
      const {
        eventName, eventPlatform, topic, email, organizerContactNumber,
        eventWebsiteUrl, dateOfEvent, lastDateOfRegistration, selectEvent,
        speakerName, organizer, address, freePaid, paidAmount, aboutEvent, speakerDetails
      } = eventData;

      const query = `
        UPDATE events
        SET eventName=?, eventPlatform=?, topic=?, email=?, organizerContactNumber=?,
            eventWebsiteUrl=?, dateOfEvent=?, lastDateOfRegistration=?, selectEvent=?,
            speakerName=?, organizer=?, address=?, freePaid=?, paidAmount=?, aboutEvent=?, speakerDetails=?
        WHERE id=?
      `;

      const [results] = await db.query(query, [
        eventName, eventPlatform, topic, email, organizerContactNumber,
        eventWebsiteUrl, dateOfEvent, lastDateOfRegistration, selectEvent,
        speakerName, organizer, address, freePaid, paidAmount, aboutEvent, speakerDetails, eventId
      ]);

      if (results.affectedRows === 0) {
        const notFoundError = new Error(`Event with id ${eventId} not found`);
        throw notFoundError;
      }

      return results;
    } catch (error) {
      console.error('Error updating event:', error);
      throw error;
    }
  },

  async deleteById(eventId) {
    try {
      const query = 'DELETE FROM events WHERE id = ?';
      const [results] = await db.query(query, [eventId]);

      if (results.affectedRows === 0) {
        const notFoundError = new Error(`Event with id ${eventId} not found`);
        throw notFoundError;
      }

      return results;
    } catch (error) {
      console.error('Error deleting event:', error);
      throw error;
    }
  }
};

module.exports = Event;