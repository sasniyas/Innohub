const db = require('../config/dbConfig');

const participantEventForm = {
  async create(participantData) {
    const {
      firstName, lastName, email, mobile, profession, country, event, payment, heardFrom, otherSource
    } = participantData;

    // Logic to determine what to store in 'heardFrom' and 'otherSource'
    let heardFromFinal = heardFrom;
    let otherSourceFinal = null;

    if (heardFrom === 'Others' && otherSource) {
      heardFromFinal = 'Others';
      otherSourceFinal = otherSource;
    }

    const query = `
      INSERT INTO participants (
        firstName, lastName, email, mobile, profession, country, payment, event, heardFrom, otherSource
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    try {
      const [results] = await db.query(query, [
        firstName, lastName, email, mobile, profession, country, payment, event,heardFrom, otherSource
      ]);

      const participantId = results.insertId;
      return participantId;
    } catch (error) {
      console.error('Error creating participant:', error);
      throw error;
    }
  },

  async findAll() {
    try {
      const query = 'SELECT * FROM participants';
      const [results] = await db.query(query);
      return results;
    } catch (error) {
      console.error('Error fetching participants:', error);
      throw error;
    }
  },

  async findById(participantId) {
    try {
      const query = 'SELECT * FROM participants WHERE id = ?';
      const [results] = await db.query(query, [participantId]);

      if (results.length === 0) {
        return null; // No participant found
      }

      return results[0];
    } catch (error) {
      console.error('Error fetching participant by id:', error);
      throw error;
    }
  },

  async updateById(participantId, participantData) {
    try {
      const {
        firstName, lastName, email, mobile, profession, country, payment, event
      } = participantData;

      const query = `
        UPDATE participants
        SET firstName=?, lastName=?, email=?, mobile=?, profession=?, country=?, payment=?, event=?
        WHERE id=?
      `;

      const [results] = await db.query(query, [
        firstName, lastName, email, mobile, profession, country, payment, event, participantId
      ]);

      if (results.affectedRows === 0) {
        const notFoundError = new Error(`Participant with id ${participantId} not found`);
        throw notFoundError;
      }

      return results;
    } catch (error) {
      console.error('Error updating participant:', error);
      throw error;
    }
  },

  async deleteById(participantId) {
    try {
      const query = 'DELETE FROM participants WHERE id = ?';
      const [results] = await db.query(query, [participantId]);

      if (results.affectedRows === 0) {
        const notFoundError = new Error(`Participant with id ${participantId} not found`);
        throw notFoundError;
      }

      return results;
    } catch (error) {
      console.error('Error deleting participant:', error);
      throw error;
    }
  }
};

module.exports = participantEventForm;
