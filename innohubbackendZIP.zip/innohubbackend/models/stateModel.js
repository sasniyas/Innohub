const db = require('../config/dbConfig');

class State {
  static async getAll() {
    try {
      const [results] = await db.query('SELECT * FROM states');
      return results;
    } catch (error) {
      console.error('Error fetching states:', error);
      throw error;
    }
  }
}

module.exports = State;
