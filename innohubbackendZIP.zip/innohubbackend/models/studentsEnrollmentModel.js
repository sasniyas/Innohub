const db = require('../config/dbConfig');

const Enrollment = {
    create: async (enrollmentData) => {
        try {
            const {
                first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no,
                gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion,
                specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr,
                achievements, upload_resume
            } = enrollmentData;

            const query = `
                INSERT INTO student_enrollment (first_name, last_name, dob, address_line1, address_line2, email_id,
                adhaar_no, mobile_no, gender, state, city, pincode, upload_photo, higher_education, marks_obtained,
                year_of_completion, specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks,
                SSC_completion_yr, achievements, upload_resume)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            const result = await db.promise().execute(query, [
                first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no,
                gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion,
                specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr,
                achievements, upload_resume
            ]);

            return result[0].insertId;
        } catch (error) {
            console.error('Error creating Enrollment:', error);
            throw error;
        }
    },

    findAll: async () => {
        try {
            const query = 'SELECT * FROM student_enrollment';
            const [rows] = await db.promise().query(query);
            return rows;
        } catch (error) {
            console.error('Error fetching Enrollments:', error);
            throw error;
        }
    },

    findById: async (id) => {
        try {
            const query = 'SELECT * FROM student_enrollment WHERE student_id = ?';
            const [rows] = await db.promise().query(query, [id]);
            return rows[0];
        } catch (error) {
            console.error('Error fetching enrollment by Id:', error);
            throw error;
        }
    },

    updateById: async (id, updatedEnrollmentData) => {
        try {
            const {
                first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no,
                gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion,
                specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr,
                achievements, upload_resume
            } = updatedEnrollmentData;

            const query = `
                UPDATE student_enrollment SET first_name=?, last_name=?, dob=?, address_line1=?, address_line2=?,
                email_id=?, adhaar_no=?, mobile_no=?, gender=?, state=?, city=?, pincode=?, upload_photo=?,
                higher_education=?, marks_obtained=?, year_of_completion=?, specialization=?, university=?,
                HSC=?, HSC_marks=?, HSC_completion_yr=?, SSC=?, SSC_marks=?, SSC_completion_yr=?, achievements=?,
                upload_resume=?
                WHERE student_id=?
            `;

            const result = await db.promise().execute(query, [
                first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no,
                gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion,
                specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr,
                achievements, upload_resume, id
            ]);

            if (result[0].affectedRows === 0) {
                throw new Error(`Enrollment with ID ${id} not found`);
            }

            return result[0];
        } catch (error) {
            console.error('Error updating Enrollment:', error);
            throw error;
        }
    }
};

module.exports = Enrollment;
