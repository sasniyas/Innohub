const db = require('../config/dbConfig');

const usermanagement = {
  async create(usermanagementData) {
    const {
      first_name, last_name, adhaar_no, email_id, Communication_Address_line_1,
      dob, city, mobile_no, pincode, gender, state, roles_name, profession
    } = usermanagementData;

    // Check if adhaar_no is provided
    if (!adhaar_no) {
      throw new Error("adhaar_no is required");
    }

    const query = 'INSERT INTO User_management_details(first_name, last_name, adhaar_no, email_id, Communication_Address_line_1, dob, city, mobile_no, pincode, gender, state, roles_name, profession) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';

    try {
      const [results] = await db.query(query, [
        first_name, last_name, adhaar_no, email_id, Communication_Address_line_1,
        dob, city, mobile_no, pincode, gender, state, roles_name, profession
      ]);

      const user_id = results.insertId;
      return user_id;
    } catch (error) {
      console.error('Error creating usermanagement:', error);
      throw error;
    }
  },

  async findAll() {
    try {
      const query = 'SELECT * FROM User_management_details';
      const [results] = await db.query(query);
      return results;
    } catch (error) {
      console.error('Error fetching User_management_details:', error);
      throw error;
    }
  },

  async findById(user_id) {
    try {
      const userIdInt = parseInt(user_id, 10);  // Convert user_id to integer
      const query = 'SELECT * FROM User_management_details WHERE user_id = ?';
      const [results] = await db.query(query, [userIdInt]);

      if (results.length === 0) {
        return null; // No user found
      }

      const user = results[0];
      const { password, ...userWithoutPassword } = user; // Destructure to remove password
      return userWithoutPassword; // Send user without password
    } catch (error) {
      console.error('Error fetching user by user_id:', error);
      throw error;
    }
  },

  async updateByuser_id(user_id, usermanagementData) {
    try {
      const {
        first_name, last_name, adhaar_no, email_id, Communication_Address_line_1,
        dob, city, mobile_no, pincode, gender, state, roles_name, profession
      } = usermanagementData;

      const query = `
        UPDATE User_management_details
        SET first_name=?, last_name=?, adhaar_no=?, email_id=?, Communication_Address_line_1=?, dob=?,
            city=?, mobile_no=?, pincode=?, gender=?, state=?, roles_name=?, profession=?
        WHERE user_id=?
      `;

      const [results] = await db.query(query, [
        first_name, last_name, adhaar_no, email_id, Communication_Address_line_1,
        dob, city, mobile_no, pincode, gender, state, roles_name, profession, user_id
      ]);

      if (results.affectedRows === 0) {
        const notFoundError = new Error(`User_management_details with user_id ${user_id} not found`);
        throw notFoundError;
      }

      return results;
    } catch (error) {
      console.error('Error updating User_management_details:', error);
      throw error;
    }
  }
};

module.exports = usermanagement;
