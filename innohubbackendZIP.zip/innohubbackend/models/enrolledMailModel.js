const db = require('../config/dbConfig');

const enrolledMailModel = {
    saveEnrollment: async (username, email, phone_number, student_id) => {
        try {
            const query = 'INSERT INTO enrollments (first_name, email_id, mobile_no, student_id) VALUES (?, ?, ?, ?)';
            const values = [username, email, phone_number, student_id];

            const [results] = await db.query(query, values);
            const enrollmentId = results.insertId;
            return enrollmentId;
        } catch (error) {
            console.error('Error saving enrollment:', error);
            throw error;
        }
    }
};

module.exports = enrolledMailModel;
