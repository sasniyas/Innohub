
const db = require('../config/dbConfig');

class permission {
  // Get all permissions
  static async getAll() {
    try {
      const [results] = await db.query('SELECT * FROM permission_table');
      return results;
    } catch (error) {
      console.error('Error fetching permissions:', error);
      throw error;
    }
  }

  // Get a permission by ID
  static async getById(id) {
    try {
      const [results] = await db.query('SELECT * FROM permission_table WHERE permission_id = ?', [id]);
      return results[0]; // Return the first result
    } catch (error) {
      console.error('Error fetching permission by ID:', error);
      throw error;
    }
  }

  // Get a permission by its name
  // static async getByName(name) {
  //   try {
  //     const [results] = await db.query('SELECT * FROM permission_table WHERE name = ?', [name]);
  //     return results[0]; // Return the first result
  //   } catch (error) {
  //     console.error('Error fetching permission by name:', error);
  //     throw error;
  //   }
  // }

  static async getByName(permission_name) {
    try {
      const [results] = await db.query('SELECT * FROM permission_table WHERE permission_name = ?', [permission_name]);
      return results[0]; // Return the first result
    } catch (error) {
      console.error('Error fetching permission by name:', error);
      throw error;
    }
  }
  

  // Create a new permission
  // static async create(permissionData) {
  //   try {
  //     const [result] = await db.query('INSERT INTO permission_table SET ?', permissionData);
  //     return result.insertId; // Return the new permission ID
  //   } catch (error) {
  //     console.error('Error creating permission:', error);
  //     throw error;
  //   }
  // }

  // Create a new permission with validation
static async create(permissionData) {
  if (!permissionData.permission_name) {
    throw new Error('Permission name is required');
  }
  // Add more validation as necessary
  try {
    const [result] = await db.query('INSERT INTO permission_table SET ?', permissionData);
    return result.insertId; // Return the new permission ID
  } catch (error) {
    console.error('Error creating permission:', error);
    throw error;
  }
}


  // Update an existing permission
  static async update(id, permissionData) {
    try {
      await db.query('UPDATE permission_table SET ? WHERE permission_id = ?', [permissionData, id]);
    } catch (error) {
      console.error('Error updating permission:', error);
      throw error;
    }
  }

  // Delete a permission
  static async delete(id) {
    try {
      await db.query('DELETE FROM permission_table WHERE permission_id = ?', [id]);
    } catch (error) {
      console.error('Error deleting permission:', error);
      throw error;
    }
  }
}

module.exports = permission;
