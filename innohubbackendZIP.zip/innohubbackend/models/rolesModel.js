const db = require('../config/dbConfig');

class Roles {
  static async getAll() {
    try {
      const [results] = await db.query('SELECT * FROM roles');
      return results;
    } catch (error) {
      console.error('Error fetching roles:', error);
      throw error;
    }
  }
}

module.exports = Roles;
