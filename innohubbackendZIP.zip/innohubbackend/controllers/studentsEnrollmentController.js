const db = require('../config/dbConfig');
require('dotenv').config();
const Enrollment = require('../models/studentsEnrollmentModel');

const getAllStudents = async (req, res) => {
  const query = `
    SELECT se.*, sm.test_score, sm.interview_score
    FROM student_enrollment se
    LEFT JOIN student_marks sm ON se.student_id = sm.student_id;
  `;
  
  try {
    const [results] = await db.query(query);
    res.json(results);
  } catch (error) {
    console.error('Error getting all students:', error);
    res.status(500).json({ error: 'Error in getting all students' });
  }
};

const getStudentById = async (req, res) => {
  const studentId = req.params.studentId; 
  try {
    const [result] = await db.query('SELECT * FROM student_enrollment WHERE student_id= ?', [studentId]);
    res.json(result);
  } catch (error) {
    console.error('Error getting student by id:', error);
    res.status(500).json({ error: 'Error in getting by id' });
  }
};

const createStudentEnrollment = async (req, res) => {
  const { first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no, gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion, specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr, achievements, upload_resume } = req.body;
  
  const query = 'INSERT INTO student_enrollment (first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no, gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion, specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr, achievements, upload_resume) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';

  try {
    await db.query(query, [first_name, last_name, dob, address_line1, address_line2, email_id, adhaar_no, mobile_no, gender, state, city, pincode, upload_photo, higher_education, marks_obtained, year_of_completion, specialization, university, HSC, HSC_marks, HSC_completion_yr, SSC, SSC_marks, SSC_completion_yr, achievements, upload_resume]);
    res.json({ message: 'Enrolled successfully' });
  } catch (error) {
    console.error('Error creating student enrollment:', error);
    res.status(500).json({ error: 'Error in creating student enrollment' });
  }
};

const updateStudent = async (req, res) => {
  const { studentId } = req.params;
  const updateFields = req.body;
  console.log("Updating student with ID:", studentId);
  const { mobile_no, address_line1, city, state } = updateFields;
  const updateQuery = 'UPDATE student_enrollment SET ? WHERE student_id = ?';
  const updateValues = {};
  if (mobile_no) updateValues.mobile_no = mobile_no;
  if (address_line1) updateValues.address_line1 = address_line1;
  if (city) updateValues.city = city;
  if (state) updateValues.state = state;
  try {
    await db.query(updateQuery, [updateValues, studentId]);
    const [updatedResult] = await db.query('SELECT * FROM student_enrollment WHERE student_id = ?', [studentId]);
    const updatedStudentInfo = updatedResult[0];
    // console.log("Updated student information retrieved:", updatedStudentInfo);
     res.status(200).json({ message: 'Updated successfully.', student: updatedStudentInfo });
  } catch (error) {
    console.error('Error updating student:', error);
    res.status(500).json({ error: 'Failed to update student.' });
  }
};

const deleteStudent = async (req, res) => {
  const studentId = req.params.studentId;
  try {
    const [result] = await db.query('DELETE FROM student_enrollment WHERE student_id = ?', [studentId]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Not found' });
    }
    res.status(200).json({ message: `id: ${studentId} deleted successfully` });
  } catch (error) {
    console.error('Error deleting student:', error);
    res.status(500).json({ error: 'Error in deleting student' });
  }
};

const getAllStudentsCount = async (req, res) => {
  try {
    const totalStudentsQuery = 'SELECT COUNT(*) as totalEnrolledStudents FROM student_enrollment';
    const totalQualifiedStudentsQuery = 'SELECT COUNT(*) as totalQualifiedStudents FROM qualified_students';
    const totalRejectedStudentsQuery = `
      SELECT COUNT(*) as totalRejectedStudents
      FROM student_enrollment se
      LEFT JOIN student_marks sm ON se.student_id = sm.student_id
      WHERE sm.test_score < 32 OR sm.interview_score < 7
    `;

    const result1 = await db.query(totalStudentsQuery);
    const result2 = await db.query(totalQualifiedStudentsQuery);
    const result3 = await db.query(totalRejectedStudentsQuery);

    //console.log('Full Result1:', JSON.stringify(result1, null, 2));
    //console.log('Full Result2:', JSON.stringify(result2, null, 2));
    //console.log('Full Result3:', JSON.stringify(result3, null, 2));

    const totalEnrolledStudents = result1[0][0]?.totalEnrolledStudents;
    const totalQualifiedStudents = result2[0][0]?.totalQualifiedStudents;
    const totalRejectedStudents = result3[0][0]?.totalRejectedStudents;

    //console.log('Total Enrolled Students:', totalEnrolledStudents);
    //console.log('Total Qualified Students:', totalQualifiedStudents);
    //console.log('Total Rejected Students:', totalRejectedStudents);

    res.json({
      totalEnrolledStudents,
      totalQualifiedStudents,
      totalRejectedStudents
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'An error occurred' });
  }
};

const deactivateStudent = async (req, res) => {
  const studentId = parseInt(req.params.studentId);
  console.log('Received studentId:', studentId);

  if (isNaN(studentId)) {
    console.error('Invalid studentId:', studentId);
    return res.status(400).json({ error: 'Invalid studentId' });
  }

  try {
    const [currentStatusResult] = await db.query('SELECT status FROM student_enrollment WHERE student_id = ?', [studentId]);
    if (currentStatusResult.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const currentStatus = currentStatusResult[0].status;
    const newStatus = currentStatus === 0 ? 1 : 0; 

    await db.query('UPDATE student_enrollment SET status = ? WHERE student_id = ?', [newStatus, studentId]);
    const message = newStatus === 1 ? `Student id: ${studentId} deactivated successfully` : `Student id: ${studentId} activated successfully`;
    res.json({ message });
  } catch (error) {
    console.error('Error updating student status:', error);
    return res.status(500).json({ error: 'Error in updating student status' });
  }
};



  module.exports = {
    getAllStudents,
    getStudentById,
    createStudentEnrollment,
    updateStudent,
    deleteStudent,
    getAllStudentsCount,
    deactivateStudent
    // getStudentsWithEnrollment
  }