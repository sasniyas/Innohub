const nodemailer = require('nodemailer');
const enrolledMailModel = require('../models/enrolledMailModel');
const dotenv = require('dotenv');
dotenv.config();

// Create transporter for sending emails
const transporter = nodemailer.createTransport({
    host: 'v9.cyberns.net', // Incoming Server
    port: 465, // SMTP Port
    secure: true, // Use SSL/TLS
    auth: {
      user: 'info@innohubrc.com', // Username
      pass: 'ZP1MTZr*c_cs', // Password
    },
    });

// Controller function to handle form submission and enrollment
const enrolledMail = async (req, res) => {
    const { first_name, email_id, mobile_no, student_id } = req.body;

    try {
        // Save enrollment data to the database
        await enrolledMailModel.saveEnrollment(first_name, email_id, mobile_no, student_id);

        // Send enrollment success email
        const mailOptions = {
            from: 'info@innohubrc.com', // Sender’s email address
            to: email_id, // Recipient’s email address
            subject: 'Enrollment Successful', // Email subject
            text: `Dear ${first_name},\n\nWe are delighted to confirm your registration for the internship screening test at InnoHub Research Centre. Your interest in contributing to our research endeavors is greatly appreciated, and we are eager to witness your potential! We look forward to having you onboard.\n\nBest regards,\nInnoHub Research Centre`, // Email body
        };

        await transporter.sendMail(mailOptions);

        res.status(200).json({ message: 'Enrollment saved successfully. Enrollment success email sent.' });
    } catch (error) {
        console.error('Error processing enrollment:', error);
        res.status(500).json({ error: 'An error occurred while processing enrollment.' });
    }
};

module.exports = {
    enrolledMail
};
