const db = require('../config/dbConfig');
require('dotenv').config();
const bcrypt = require('bcrypt');
const usermanagement = require('../models/usermanagementModel');

const getAllusermanagement = async (req, res) => {
    try {
        const [results] = await db.query('SELECT * FROM User_management_details');
        res.json(results);
    } catch (error) {
        res.status(500).json({ error: 'Error in getting usermanagement details' });
    }
};

const getusermanagementByuser_id = async (req, res) => {
    const user_id = req.params.user_id;
    const getByuser_idQuery = "SELECT * FROM User_management_details WHERE user_id = ?";
    try {
        const [result] = await db.query(getByuser_idQuery, [user_id]);
        res.json(result);
    } catch (err) {
        console.error('Error getting usermanagement:', err);
        res.status(500).json({ error: 'Error in getting by user_id' });
    }
};

const createusermanagement = async (req, res) => {
    const {
        first_name, last_name, adhaar_no, email_id, Communication_Address_line_1, dob, city, mobile_no, pincode, gender, state, roles_name, profession
    } = req.body;

    const query = `INSERT INTO User_management_details(first_name, last_name, adhaar_no, email_id, Communication_Address_line_1, dob, city, mobile_no, pincode, gender, state, roles_name, profession)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    try {
        await db.query(query, [first_name, last_name, adhaar_no, email_id, Communication_Address_line_1, dob, city, mobile_no, pincode, gender, state, roles_name, profession]);
        res.json({ message: 'User management created successfully' });
    } catch (err) {
        console.error('Error creating user management:', err);
        res.status(500).json({ error: 'Error in creating user management' });
    }
};

const updateusermanagement = async (req, res) => {
  const { user_id } = req.params;
  const updateFields = req.body;
  const { mobile_no, city, state, profession, Communication_Address_line_1 } = updateFields;
  const updateValues = {};
  if (mobile_no) updateValues.mobile_no = mobile_no;
  if (city) updateValues.city = city;
  if (state) updateValues.state = state;
  if (profession) updateValues.profession = profession;
  if (Communication_Address_line_1) updateValues.Communication_Address_line_1 = Communication_Address_line_1;
  if (Object.keys(updateValues).length === 0) {
    return res.status(400).json({ error: 'No fields to update.' });
  }
  const setClause = Object.keys(updateValues)
    .map(field => `${field} = ?`)
    .join(', ');
  const queryParams = [...Object.values(updateValues), user_id];
  const updateQuery = `UPDATE User_management_details SET ${setClause} WHERE user_id = ?`;
  const selectQuery = 'SELECT * FROM User_management_details WHERE user_id = ?';
  try {
    await db.query(updateQuery, queryParams);
    const [updatedResults] = await db.query(selectQuery, [user_id]);
    const updatedUserInfo = updatedResults[0];
    res.status(200).json({ message: 'Updated successfully.', user: updatedUserInfo });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user.' });
  }
};

// const deactivateusermanagement = async (req, res) => {
//   const user_id = parseInt(req.params.user_id);
//   if (isNaN(user_id)) {
//     console.error('Invalid userId:', user_id);
//     return res.status(400).json({ error: 'Invalid userId' });
//   }
//   try {
//     const [currentStatusResult] = await db.query('SELECT status FROM user_management_details WHERE user_id = ?', [user_id]);
//     if (currentStatusResult.length === 0) {
//       console.error(`User with id ${user_id} not found`);
//       return res.status(404).json({ error: 'User not found' });
//     }
//     const currentStatus = currentStatusResult[0].status;
//     const newStatus = currentStatus === 1? 0 : 1; // Toggle the status
//     await db.query('UPDATE user_management_details SET status = ? WHERE user_id = ?', [newStatus, user_id]);
//     const message = newStatus === 0
//       ? `User with id ${user_id} has been deactivated successfully`
//       : `User with id ${user_id} has been activated successfully`;
//     res.json({ message });
//   } catch (error) {
//     console.error('Error updating user status:', error);
//     res.status(500).json({ error: 'Error updating user status' });
//   }
// };

const deleteusermanagement = async (req, res) => {
    const user_id = req.params.user_id;

    const deleteQuery = 'DELETE FROM User_management_details WHERE user_id = ?';

    try {
        const [result] = await db.query(deleteQuery, [user_id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'User management not found' });
        }

        res.status(200).json({ message: `User management with user_id: ${user_id} deleted successfully` });
    } catch (err) {
        console.error('Error deleting user management:', err);
        res.status(500).json({ error: 'Error in deleting user management' });
    }
};

const updateUserProfile = async (req, res) => {
    const user_id = req.params.user_id;
    const { first_name, last_name,Communication_Address_line_1, mobile_no } = req.body;
    const photo = req.file ? req.file.path : null;
  
    try {
      // Check if user exists
      const [userExists] = await db.query('SELECT * FROM User_management_details WHERE user_id = ?', [user_id]);
      if (userExists.length === 0) {
        return res.status(404).json({ error: 'User management not found' });
      }
  
      // Construct the update query
      const updateQuery = `
        UPDATE User_management_details 
        SET first_name = ?, last_name = ?, Communication_Address_line_1= ?, mobile_no = ?, photo = ? 
        WHERE user_id = ?`;
  
      // Execute the update query
      await db.query(updateQuery, [first_name, last_name,Communication_Address_line_1, mobile_no, photo, user_id]);
  
      // Fetch the updated user details
      const [updatedUser] = await db.query('SELECT * FROM User_management_details WHERE user_id = ?', [user_id]);
  
      res.status(200).json({ message: 'Profile updated successfully', user: updatedUser[0] });
    } catch (error) {
      console.error('Error updating user profile:', error);
      res.status(500).json({ error: 'Failed to update profile' });
    }
  };

  const updatePassword = async (req, res) => {
    const { new_password, confirm_password } = req.body;
  
    // Ensure the passwords match
    if (new_password !== confirm_password) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }
  
    //const user_id = req.user.user_id; // Assuming the user ID is stored in req.user by the auth middleware
    const user_id = req.params.user_id;
    try {
      // Hash the new password
      const hashedPassword = await bcrypt.hash(new_password, 10);
  
      // Update the password in the database
      const updateQuery = `UPDATE user_credentials SET password = ? WHERE id = ?`;
      await db.query(updateQuery, [hashedPassword, user_id]);
  
      res.status(200).json({ message: 'Password updated successfully' });
    } catch (error) {
      console.error('Error updating password:', error);
      res.status(500).json({ error: 'Failed to update password' });
    }
  };

  const logout = async (req, res) => {
    try {
      // Here you can perform any additional server-side cleanup if needed
      // For example, logging the logout event
  
      res.status(200).json({ message: 'Logout successful' });
    } catch (error) {
      console.error('Error during logout:', error);
      res.status(500).json({ error: 'An error occurred during logout' });
    }
  };
  
  
module.exports = {
    getAllusermanagement,
    getusermanagementByuser_id,
    createusermanagement,
    updateusermanagement,
    deleteusermanagement,
    updateUserProfile,
    updatePassword,
    logout
};