const db = require('../config/dbConfig');
require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: 'v9.cyberns.net', // Incoming Server
  port: 465, // SMTP Port
  secure: true, // Use SSL/TLS
  auth: {
    user: 'info@innohubrc.com', // Username
    pass: 'ZP1MTZr*c_cs', // Password
  },
  });

const sendMail = async (req, res) => {
    const { firstName, lastName, email, query } = req.body;

    const mailOptions = {
        from: email,
        to: 'info@innohubrc.com',
        subject: 'New Query from User',
           
        html: `
        <p><strong>Name:</strong> ${firstName} ${lastName}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Query:</strong> ${query}</p>
      `,
   
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        res.status(200).send('Email sent: ' + info.response);
    } catch (error) {
        console.error('Error occurred:', error.message);
        res.status(500).send('Error occurred: ' + error.message);
    }
};

module.exports = { sendMail };
