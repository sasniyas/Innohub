const db = require('../config/dbConfig');
require('dotenv').config();
const roles = require('../models/rolesModel');
const permission = require('../models/permissionModel');
const rolespermission = require('../models/rolepermissionModel');

const getAllroles = async (req, res) => {
  try {
    const allRoles = await roles.getAll();
    res.json(allRoles);
  } catch (error) {
    console.error('Error getting roles:', error);
    res.status(500).json({ error: 'Error in getting roles' });
  }
};

const access = async (req, res) => {
  const { rolesId, permission_names } = req.body; // Updated to accept an array of permission names

  // try {
  //   // Fetch permissions by their names
  //   const permissionsFound = await Promise.all(
  //     permission_names.map(name => permission.getByName(name))
  //   );

  // if (!Array.isArray(permission_names)) {
  //   return res.status(400).json({ message: 'permission_names must be an array' });
  // }

  try {
    // Fetch permissions by their names
    const permissionsFound = await Promise.all(
      permission_names.map(name => permission.getByName(name))
    );
    // Filter out any not found permissions
    const validPermissions = permissionsFound.filter(p => p);
    const notFoundPermissions = permission_names.filter(
      (name, index) => !permissionsFound[index]
    );

    // If there are any permissions not found, return a 404 error
    if (notFoundPermissions.length > 0) {
      return res.status(404).json({ message: 'Permissions not found', notFound: notFoundPermissions });
    }

    // Create role-permission mappings
    const rolePermissionData = validPermissions.map(p => ({
      roles_id: rolesId,
      permission_id: p.permission_id,
    }));

    const rolePermissionIds = await Promise.all(
      rolePermissionData.map(data => rolespermission.create(data))
    );

    return res.status(201).json({
      message: 'Permissions assigned to role successfully',
      rolePermissionIds,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
};

module.exports = { 
  getAllroles,
  access
};


// // const db = require('../config/dbConfig');
// // require('dotenv').config();
// // const roles = require('../models/rolesModel');
// // const permission = require('../models/permissionModel');
// // const rolespermission = require('../models/rolepermissionModel');

// // const getAllroles = async (req, res) => {
// //   try {
// //     const allRoles = await roles.getAll();
// //     res.json(allRoles);
// //   } catch (error) {
// //     console.error('Error getting roles:', error);
// //     res.status(500).json({ error: 'Error in getting roles' });
// //   }
// // };

// // const access = async (req, res) => {
// //   const { rolesId, permission_names } = req.body;

// //   if (!rolesId || !Array.isArray(permission_names) || permission_names.length === 0) {
// //     return res.status(400).json({ message: 'rolesId is required and permission_names must be a non-empty array' });
// //   }

// //   try {
// //     // Check if the role exists
// //     const role = await roles.getById(rolesId);
// //     if (!role) {
// //       return res.status(404).json({ message: 'Role not found' });
// //     }

// //     // Fetch permissions and validate
// //     const permissionsFound = await Promise.all(
// //       permission_names.map(name => permission.getByName(name))
// //     );

// //     const validPermissions = permissionsFound.filter(p => p);
// //     const notFoundPermissions = permission_names.filter(
// //       (name, index) => !permissionsFound[index]
// //     );

// //     // Handle not found permissions
// //     if (notFoundPermissions.length > 0) {
// //       return res.status(404).json({ message: 'Permissions not found', notFound: notFoundPermissions });
// //     }

// //     // Create role-permission mappings
// //     const rolePermissionData = validPermissions.map(p => ({
// //       roles_id: rolesId,
// //       permission_id: p.permission_id,
// //     }));

// //     const rolePermissionIds = await Promise.all(
// //       rolePermissionData.map(data => rolespermission.create(data))
// //     );

// //     return res.status(201).json({
// //       message: 'Permissions assigned to role successfully',
// //       rolePermissionIds,
// //     });
// //   } catch (error) {
// //     console.error('Error assigning permissions:', error);
// //     return res.status(500).json({ message: 'Internal Server Error' });
// //   }
// // };

// // module.exports = { 
// //   getAllroles,
// //   access
// // };


// const db = require('../config/dbConfig');
// require('dotenv').config();
// const SECRET_KEY = process.env; // Ensure you have your secret key from .env
// const roles = require('../models/rolesModel');
// const permission = require('../models/permissionModel');
// const rolespermission = require('../models/rolepermissionModel');

// const getAllroles = async (req, res) => {
//   try {
//     const allRoles = await roles.getAll();
//     return res.json(allRoles);
//   } catch (error) {
//     console.error('Error getting roles:', error);
//     return res.status(500).json({ error: 'Error in getting roles' });
//   }
// };

// const access = async (req, res) => {
//   const { rolesId, permission_names } = req.body;

//   // Validate input
//   if (!rolesId || typeof rolesId !== 'number' || !Array.isArray(permission_names) || permission_names.length === 0) {
//     return res.status(400).json({ message: 'Invalid input: rolesId must be a valid number and permission_names must be a non-empty array' });
//   }

//   try {
//     // Check if the role exists
//     const role = await roles.getById(rolesId);
//     if (!role) {
//       return res.status(404).json({ message: 'Role not found' });
//     }

//     // Fetch permissions and validate
//     const permissionsFound = await Promise.all(
//       permission_names.map(name => permission.getByName(name))
//     );

//     const validPermissions = permissionsFound.filter(p => p);
//     const notFoundPermissions = permission_names.filter((name, index) => !permissionsFound[index]);

//     // Handle not found permissions
//     if (notFoundPermissions.length > 0) {
//       return res.status(404).json({ message: 'Permissions not found', notFound: notFoundPermissions });
//     }

//     // Create role-permission mappings
//     const rolePermissionData = validPermissions.map(p => ({
//       roles_id: rolesId,
//       permission_id: p.permission_id,
//     }));

//     // Use a single query to insert all role-permission mappings, if supported by your database
//     const rolePermissionIds = await Promise.all(rolePermissionData.map(data => rolespermission.create(data)));

//     return res.status(201).json({
//       message: 'Permissions assigned to role successfully',
//       rolePermissionIds,
//     });
//   } catch (error) {
//     console.error('Error assigning permissions:', error);
//     return res.status(500).json({ message: 'Internal Server Error' });
//   }
// };
// //  
// // // const access = async (req, res) => {
// // //   const { rolesId, permission_names } = req.body;

// // //   // Validate input
// // //   if (!rolesId || typeof rolesId !== 'number' || !Array.isArray(permission_names) || permission_names.length === 0) {
// // //     return res.status(400).json({ message: 'Invalid input: rolesId must be a valid number and permission_names must be a non-empty array' });
// // //   }

// // //   try {
// // //     // Access the user ID from the decoded token
// // //     const userId = req.user.user_id; // Assuming user_id is part of your JWT payload

// // //     // Check if the role exists
// // //     const role = await roles.getById(rolesId);
// // //     if (!role) {
// // //       return res.status(404).json({ message: 'Role not found' });
// // //     }

// // //     // Fetch permissions and validate
// // //     const permissionsFound = await Promise.all(
// // //       permission_names.map(name => permission.getByName(name))
// // //     );

// // //     const validPermissions = permissionsFound.filter(p => p);
// // //     const notFoundPermissions = permission_names.filter((name, index) => !permissionsFound[index]);

// // //     // Handle not found permissions
// // //     if (notFoundPermissions.length > 0) {
// // //       return res.status(404).json({ message: 'Permissions not found', notFound: notFoundPermissions });
// // //     }

// // //     // Create role-permission mappings
// // //     const rolePermissionData = validPermissions.map(p => ({
// // //       roles_id: rolesId,
// // //       permission_id: p.permission_id,
// // //       assigned_by: userId, // Log who assigned the permissions
// // //     }));

// // //     // Insert all role-permission mappings
// // //     const rolePermissionIds = await Promise.all(rolePermissionData.map(data => rolespermission.create(data)));

// // //     return res.status(201).json({
// // //       message: 'Permissions assigned to role successfully',
// // //       rolePermissionIds,
// // //     });
// // //   } catch (error) {
// // //     console.error('Error assigning permissions:', error);
// // //     return res.status(500).json({ message: 'Internal Server Error' });
// // //   }
// // // };

// // const access = async (req, res) => {
// //   const { rolesId, permission_names, token } = req.body; // Include token in destructuring

// //   // Validate input
// //   if (!rolesId || typeof rolesId !== 'number' || !Array.isArray(permission_names) || permission_names.length === 0 || !token) {
// //     return res.status(400).json({ message: 'Invalid input: rolesId must be a valid number, permission_names must be a non-empty array, and token must be provided' });
// //   }

// //   try {
// //     // Verify the token and extract user information
// //     const decoded = jwt.verify(token, SECRET_KEY); // Assuming SECRET_KEY is defined in your environment variables
// //     const userId = decoded.user_id; // Extract user ID from the decoded token

// //     // Check if the role exists
// //     const role = await roles.getById(rolesId);
// //     if (!role) {
// //       return res.status(404).json({ message: 'Role not found' });
// //     }

// //     // Fetch permissions and validate
// //     const permissionsFound = await Promise.all(
// //       permission_names.map(name => permission.getByName(name))
// //     );

// //     const validPermissions = permissionsFound.filter(p => p);
// //     const notFoundPermissions = permission_names.filter((name, index) => !permissionsFound[index]);

// //     // Handle not found permissions
// //     if (notFoundPermissions.length > 0) {
// //       return res.status(404).json({ message: 'Permissions not found', notFound: notFoundPermissions });
// //     }

// //     // Create role-permission mappings
// //     const rolePermissionData = validPermissions.map(p => ({
// //       roles_id: rolesId,
// //       permission_id: p.permission_id,
// //       assigned_by: userId, // Log who assigned the permissions
// //     }));

// //     // Insert all role-permission mappings
// //     const rolePermissionIds = await Promise.all(rolePermissionData.map(data => rolespermission.create(data)));

// //     return res.status(201).json({
// //       message: 'Permissions assigned to role successfully',
// //       rolePermissionIds,
// //     });
// //   } catch (error) {
// //     console.error('Error assigning permissions:', error);
// //     if (error.name === 'JsonWebTokenError') {
// //       return res.status(401).json({ message: 'Invalid token' });
// //     }
// //     return res.status(500).json({ message: 'Internal Server Error' });
// //   }
// // };


// // const checkUserRole = async (req, res, next) => {
// //   if (!req.user || !req.user.user_id) {
// //     return res.status(401).json({ error: 'Unauthorized: User not logged in' });
// //   }

// //   try {
// //     const results = await db.query(
// //       'SELECT role_id FROM User_management_details WHERE user_id = ?',
// //       [req.user.user_id]
// //     );

// //     if (results.length === 0) {
// //       return res.status(403).json({ error: 'Forbidden: User role not found' });
// //     }

// //     req.user.roleId = results[0].role_id; // Set roleId on req.user
// //     next();
// //   } catch (err) {
// //     return res.status(500).json({ error: 'Internal Server Error' });
// //   }
// // };


// module.exports = { 
//   getAllroles,
//   access,
//   //  checkUserRole
// };
