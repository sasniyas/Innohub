const crypto = require('crypto');
const db = require('../config/dbConfig');
const nodemailer = require('nodemailer');
require('dotenv').config();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { SECRET_KEY } = process.env;
const transporter = nodemailer.createTransport({
    host: 'v9.cyberns.net', // Incoming Server
    port: 465, // SMTP Port
    secure: true, // Use SSL/TLS
    auth: {
      user: 'info@innohubrc.com', // Username
      pass: 'ZP1MTZr*c_cs', // Password
    },
    });
function generateNumericOTP(length) {
    let otp = '';
    for (let i = 0; i < length; i++) {
        otp += Math.floor(Math.random() * 10);
    }
    return otp;
}
const SendingOTP = async (req, res) => {
    const { email_id } = req.body;
    try {
        const [userResults] = await db.query('SELECT username FROM user_credentials WHERE email_id = ?', [email_id]);
        if (userResults.length === 0) {
            return res.status(404).json({ message: 'Email not found' });
        }
        const username = userResults[0].username;
        const otp = generateNumericOTP(6);
        const token = jwt.sign({ email_id }, SECRET_KEY, { expiresIn: '1h' });
        const expiry = new Date(Date.now() + 5 * 60 * 1000);
        await db.query('INSERT INTO forgot_password (email_id, otp, token, otpexpiry) VALUES (?, ?, ?, ?)', [email_id, otp, token, expiry]);
        const mailOptions = {
            from: 'info@innohubrc.com',
            to: email_id,
            subject: 'Your OTP for password reset',
            text: `Hello ${username},\n\nYour OTP is ${otp}.\n\nPlease use this OTP to reset your password.\n\nBest regards,\nYour Company`
        };
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return res.status(500).json({ message: 'Error sending OTP email', error: error.message });
            }
            console.log('Email sent:', info.response);
            res.json({ message: 'OTP sent successfully', token });
        });
    } catch (err) {
        console.error('Error executing query or sending email:', err);
        res.status(500).json({ message: 'Internal server error', error: err.message });
    }
};

const ResendOtp = async (req, res) => {
    const { token } = req.body;
    if (!token) {
        return res.status(400).json({ message: 'No reset token provided' });
    }
    try {
        const [results] = await db.query('SELECT email_id FROM forgot_password WHERE token = ?', [token]);
        if (results.length === 0) {
            return res.status(400).json({ message: 'Invalid or expired token' });
        }
        const email_id = results[0].email_id;
        const [userResults] = await db.query('SELECT username FROM user_credentials WHERE email_id = ?', [email_id]);
        if (userResults.length === 0) {
            return res.status(404).json({ message: 'Email not found' });
        }
        const username = userResults[0].username;
        const newotp = generateNumericOTP(6);
        const newexpiry = new Date(Date.now() + 5 * 60 * 1000);
        const [updateResult] = await db.query(
            'UPDATE forgot_password SET otp = ?, otpexpiry = ? WHERE token = ?',
            [newotp, newexpiry, token]
        );

        if (updateResult.affectedRows === 0) {
            return res.status(400).json({ message: 'Failed to update OTP. Token might be invalid.' });
        }
        const mailOptions = {
            from: 'info@innohubrc.com',
            to: email_id,
            subject: 'Your OTP for password reset',
            text: `Hello ${username},\n\nYour new OTP is ${newotp}.\n\nPlease use this OTP to reset your password.\n\nBest regards,\nYour Company`
        };
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return res.status(500).json({ message: 'Error sending OTP email', error: error.message });
            }

            console.log('Email sent:', info.response);
            res.json({ message: 'OTP resent successfully' });
        });
    } catch (err) {
        console.error('Error executing query or sending email:', err);
        res.status(500).json({ message: 'Internal server error', error: err.message });
    }
};

const VerifyOTP = async (req, res) => {
    const { token, otp } = req.body;
    try {
        if (!token || !otp) {
            return res.status(400).json({ message: 'Token and OTP are required' });
        }
        const [tokenResults] = await db.query('SELECT email_id FROM forgot_password WHERE token = ?', [token]);
        if (tokenResults.length === 0) {
            return res.status(400).json({ message: 'Invalid or expired token' });
        }
        const email_id = tokenResults[0].email_id;
        const [otpResults] = await db.query(
            'SELECT otp, otpexpiry FROM forgot_password WHERE email_id = ? ORDER BY created_at DESC LIMIT 1',
            [email_id]
        );
        if (otpResults.length === 0) {
            return res.status(400).json({ message: 'No OTP found for this email' });
        }
        const { otp: storedOtp, otpexpiry } = otpResults[0];
        if (storedOtp !== otp) {
            return res.status(400).json({ message: 'Invalid OTP' });
        }
        if (new Date() > new Date(otpexpiry)) {
            return res.status(400).json({ message: 'OTP has expired' });
        }
        await db.query('UPDATE forgot_password SET otp = NULL WHERE email_id = ?', [email_id]);
        res.json({ message: 'OTP verified successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Internal server error', error: err.message });
    }
};

const ResetPassword = async (req, res) => {
    const { newPassword, confirmPassword } = req.body;
    const token = req.headers.authorization?.split(' ')[1]?.trim();
    if (!token) {
        return res.status(403).json({ error: 'No reset token provided' });
    }
    if (newPassword !== confirmPassword) {
        return res.status(400).json({ error: 'Passwords do not match' });
    }
    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        const { email_id } = decoded;
        if (!email_id) {
            throw new Error('Invalid token payload');
        }
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const [result] = await db.query('UPDATE user_credentials SET password = ? WHERE email_id = ?', [hashedPassword, email_id]);
        if (result.affectedRows === 0) {
            throw new Error('No user found with the provided email ID');
        }
        await db.query('DELETE FROM forgot_password WHERE email_id = ?', [email_id]);
        res.json({ message: 'Password reset successfully' });
    } catch (error) {
        res.status(401).json({ error: 'Invalid or expired reset token', details: error.message });
    }
};

module.exports = {
    SendingOTP,
    ResendOtp,
    VerifyOTP,
    ResetPassword
};
