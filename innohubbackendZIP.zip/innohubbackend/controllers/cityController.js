const db = require('../config/dbConfig');
require('dotenv').config();
const City = require('../models/cityModel');

const getCitiesByState = async (req, res) => {
  const stateId = req.params.stateId;
  try {
    const cities = await City.getByState(stateId);
    res.json(cities);
  } catch (error) {
    console.error('Error getting cities by state:', error);
    res.status(500).json({ error: 'Error in getting cities by state' });
  }
};

const getAllCities = async (req, res) => {
  try {
    const [results] = await db.query('SELECT * FROM cities');
    res.json(results);
  } catch (error) {
    console.error('Error getting all cities:', error);
    res.status(500).json({ error: 'Error in getting all cities' });
  }
};

const getCitiesById = async (req, res) => {
  const cityId = req.params.cityId;
  try {
    const [result] = await db.query('SELECT * FROM cities WHERE city_id = ?', [cityId]);
    res.json(result);
  } catch (error) {
    console.error('Error getting city by id:', error);
    res.status(500).json({ error: 'Error in getting city by id' });
  }
};

const createCities = async (req, res) => {
  const { city_name, state_name, creation_date } = req.body;
  try {
    const [stateIdResult] = await db.query('SELECT state_id FROM states WHERE state_name = ?', [state_name]);
    if (stateIdResult.length === 0) {
      return res.status(400).json({ error: 'State not found' });
    }
    const state_id = stateIdResult[0].state_id;

    const [insertResult] = await db.query('INSERT INTO cities (city_name, state_id, state_name, creation_date, status) VALUES (?, ?, ?, ?, ?)', [city_name, state_id, state_name, creation_date, 0]);
    res.json({ message: 'City created successfully' });
  } catch (error) {
    console.error('Error creating city:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const updateCities = async (req, res) => {
  const { cityId } = req.params;
  const updateFields = req.body;
  try {
    const [existingCity] = await db.query('SELECT * FROM cities WHERE city_id = ?', [cityId]);
    if (existingCity.length === 0) {
      return res.status(404).json({ error: 'City not found.' });
    }

    const { city_name, state_name, state_id, creation_date } = updateFields;
    const updatedCity = { city_name, state_name, state_id, creation_date };

    await db.query('UPDATE cities SET ? WHERE city_id = ?', [updatedCity, cityId]);
    const [updatedResult] = await db.query('SELECT * FROM cities WHERE city_id = ?', [cityId]);
    const updatedCityInfo = updatedResult[0];
    res.status(200).json({ message: 'City updated successfully.', city: updatedCityInfo });
  } catch (error) {
    console.error('Error updating city:', error);
    res.status(500).json({ error: 'Failed to update city.' });
  }
};

const deactivateCities = async (req, res) => {
  const cityId = parseInt(req.params.cityId);

  if (isNaN(cityId)) {
    console.error('Invalid cityId:', cityId);
    return res.status(400).json({ error: 'Invalid cityId' });
  }

  try {
    const [currentStatusResult] = await db.query('SELECT status FROM cities WHERE city_id = ?', [cityId]);
    if (currentStatusResult.length === 0) {
      return res.status(404).json({ error: 'City not found' });
    }

    const currentStatus = currentStatusResult[0].status;

    const newStatus = currentStatus === 0 ? 1 : 0;

    const [result] = await db.query('UPDATE cities SET status = ? WHERE city_id = ?', [newStatus, cityId]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'City not found' });
    }

    const message = newStatus === 1 ? `City id: ${cityId} deactivated successfully` : `City id: ${cityId} activated successfully`;
    res.json({ message });
  } catch (error) {
    console.error('Error updating city status:', error);
    res.status(500).json({ error: 'Error in updating city status' });
  }
};

module.exports = { 
  getCitiesByState,
  getAllCities,
  getCitiesById,
  createCities,
  updateCities,
  deactivateCities
};
