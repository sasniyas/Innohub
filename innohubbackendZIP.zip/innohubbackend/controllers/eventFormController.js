const Event = require('../models/eventFormModel');

const getAllEvents = async (req, res) => {
  try {
    const events = await Event.findAll();
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const getEventById = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (event) {
      res.json(event);
    } else {
      res.status(404).json({ error: 'Event not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const createEvent = async (req, res) => {
  try {
    const newEvent = await Event.create(req.body);
   // res.status(201).json(newEvent);
   res.json({ message: 'Enrolled successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const updateEvent = async (req, res) => {
  try {
    const updatedEvent = await Event.updateById(req.params.id, req.body);
    if (updatedEvent) {
      res.status(200).json({ message: 'Updated successfully.', student: updatedStudentInfo });
      //res.json(updatedEvent);
    } else {
      res.status(404).json({ error: 'Event not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const deleteEvent = async (req, res) => {
  try {
    const deleted = await Event.deleteById(req.params.id);
    if (deleted) {
      //res.status(204).end();
      res.status(200).json({ message: `id: ${studentId} deleted successfully` });
    } else {
      res.status(404).json({ error: 'Event not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = {
  getAllEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent,
};
