const db = require('../config/dbConfig');
require('dotenv').config();
const degree = require('../models/higherEducationModel');

const getAllDegrees = async (req, res) => {
  try {
    const degrees = await degree.getAll();
    res.json(degrees);
  } catch (error) {
    console.error('Error getting degrees:', error);
    res.status(500).json({ error: 'Error in getting degrees' });
  }
};

const getDegreesById = async (req, res) => {
  const degreeId = req.params.degreeId;

  try {
    const [result] = await db.query('SELECT * FROM higher_education WHERE degree_id = ?', [degreeId]);
    res.json(result);
  } catch (error) {
    console.error('Error getting degree:', error);
    res.status(500).json({ error: 'Error in getting degree by id' });
  }
};

/*const createDegrees = async (req, res) => {
  const { degree_name, creation_date } = req.body;

  try {
    const [existingDegrees] = await db.query('SELECT * FROM higher_education WHERE degree_name = ?', [degree_name]);
    if (existingDegrees.length > 0) {
      return res.status(400).json({ error: 'Degree name is already available, provide a new degree name' });
    }

    await db.query('INSERT INTO higher_education (degree_name, creation_date, status) VALUES (?, ?, ?)', [degree_name, creation_date, 0]);
    res.json({ message: 'Degree created successfully' });
  } catch (error) {
    console.error('Error creating degree:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};*/
const createDegrees = async (req, res) => {
  const { degree_name, creation_date } = req.body;

  const normalizedDegreeName = degree_name
    .replace(/[^\w\s]/gi, '') // remove special characters
    .trim() // remove leading and trailing whitespace
    .toLowerCase(); // convert to lowercase

  try {
    const [existingDegrees] = await db.query('SELECT * FROM higher_education', []);

    const existingDegree = existingDegrees.find((degree) => {
      const normalizedExistingDegreeName = degree.degree_name
        .replace(/[^\w\s]/gi, '') // remove special characters
        .trim() // remove leading and trailing whitespace
        .toLowerCase(); // convert to lowercase
      return normalizedExistingDegreeName === normalizedDegreeName;
    });

    if (existingDegree) {
      return res.status(400).json({ error: 'Degree name already exists, please provide a new degree name' });
    }

    await db.query('INSERT INTO higher_education (degree_name, creation_date, status) VALUES (?, ?, ?)', [degree_name, creation_date, 0]);
    res.json({ message: 'Degree created successfully' });
  } catch (error) {
    console.error('Error creating degree:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const updateDegrees = async (req, res) => {
  const { degreeId } = req.params;
  const updateFields = req.body;

  try {
    const [existingDegrees] = await db.query('SELECT * FROM higher_education WHERE degree_id = ?', [degreeId]);
    if (existingDegrees.length === 0) {
      return res.status(404).json({ error: 'Degree not found.' });
    }

    const { degree_name, creation_date } = updateFields;
    const updatedDegree = { degree_name, creation_date };

    await db.query('UPDATE higher_education SET ? WHERE degree_id = ?', [updatedDegree, degreeId]);
    
    const [updatedRows] = await db.query('SELECT * FROM higher_education WHERE degree_id = ?', [degreeId]);
    const updatedDegreeInfo = updatedRows[0];
    
    res.status(200).json({ message: 'Degree updated successfully.', degree: updatedDegreeInfo });
  } catch (error) {
    console.error('Error updating degree:', error);
    res.status(500).json({ error: 'Failed to update degree.' });
  }
};

const deactivateDegrees = async (req, res) => {
  const degreeId = parseInt(req.params.degreeId);

  if (isNaN(degreeId)) {
    console.error('Invalid degreeId:', degreeId);
    return res.status(400).json({ error: 'Invalid degreeId' });
  }

  try {
    const [currentStatusResult] = await db.query('SELECT status FROM higher_education WHERE degree_id = ?', [degreeId]);
    if (currentStatusResult.length === 0) {
      return res.status(404).json({ error: 'Degree not found' });
    }

    const currentStatus = currentStatusResult[0].status;
    const newStatus = currentStatus === 0 ? 1 : 0;

    const [result] = await db.query('UPDATE higher_education SET status = ? WHERE degree_id = ?', [newStatus, degreeId]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Degree not found' });
    }

    const message = newStatus === 1 ? `Degree id: ${degreeId} deactivated successfully` : `Degree id: ${degreeId} activated successfully`;
    res.json({ message });
  } catch (error) {
    console.error('Error updating degree status:', error);
    res.status(500).json({ error: 'Error in updating degree status' });
  }
};

module.exports = { 
  getAllDegrees,
  getDegreesById,
  createDegrees,
  updateDegrees,
  deactivateDegrees  
};
