const db = require('../config/dbConfig');
require('dotenv').config();
const nodemailer = require('nodemailer');
const express = require('express');

const app = express();
app.use(express.json()); 

const createStudentMarks = async (req, res) => {
  const { student_id, test_score, interview_score } = req.body;
  console.log("student_id:", student_id);
  console.log("test_score:", test_score);
  console.log("interview_score:", interview_score);

  if (!student_id || !test_score || !interview_score) {
    return res.status(400).json({ error: 'Student ID, test score, and interview score are required.' });
  }

  try {
    const [result] = await db.query('INSERT INTO student_marks (student_id, test_score, interview_score) VALUES (?, ?, ?)', [student_id, test_score, interview_score]);
    res.status(201).json({ message: 'Student marks added successfully.', student_id: result.insertId });
    console.log("Response:", { message: 'Student marks added successfully.', student_id: result.insertId });
  } catch (error) {
    console.error("Error inserting student marks:", error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

function isQualified(testScore, interviewScore) {
  return testScore >= 32 && interviewScore >= 7;
}

function generateRollNumber() {
  const firstRandom = Math.floor(Math.random() * 90) + 10; 
  const secondRandom = Math.floor(Math.random() * 900) + 100; 

  return `INAI ${firstRandom}B${secondRandom}`;
}

const getStudentMarks = async (req, res) => {
  const { qualified } = req.query;

  if (qualified === 'true') {
    getQualifiedStudents(req, res);
  } else {
    try {
      const [studentMarks] = await db.query('SELECT * FROM student_marks');
      for (const student of studentMarks) {
        const { student_id, test_score, interview_score } = student;
        const qualified = isQualified(test_score, interview_score);
        const roll_no = generateRollNumber();

        if (qualified) {
          const [results] = await db.query('SELECT * FROM qualified_students WHERE student_id = ?', [student_id]);
          if (results.length === 0) {
            await db.query('INSERT INTO qualified_students (student_id, test_score, interview_score, roll_no) VALUES (?, ?, ?, ?)', [student_id, test_score, interview_score, roll_no]);
          } else {
            console.log(`Student with ID ${student_id} is already qualified.`);
          }
        } else {
          // Rejected
        }
      }
      console.log("Processing complete.");
      res.status(200).json({ message: "Processing complete.", studentMarks });
    } catch (error) {
      console.error("Error fetching student marks:", error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }
};

const getQualifiedStudents = async (req, res) => {
  try {
    const [results] = await db.query('SELECT qs.student_id, se.first_name, se.last_name, se.email_id, se.mobile_no, se.gender, se.dob, se.address_line1, se.state, se.city, se.adhaar_no, se.higher_education, qs.test_score, qs.interview_score, qs.roll_no FROM qualified_students qs INNER JOIN student_enrollment se ON qs.student_id = se.student_id');
    res.json(results);
  } catch (error) {
    console.error('Error in getting qualified students:', error);
    res.status(500).json({ error: 'Error in getting qualified students' });
  }
};

const sendEmail = async (req, res) => {
  const { studentId } = req.params;
  console.log("selected studentId:", studentId);

  try {
    const [studentDetails] = await db.query('SELECT test_score, interview_score FROM student_marks WHERE student_id = ?', [studentId]);

    if (studentDetails.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const { test_score, interview_score } = studentDetails[0];
    const qualified = isQualified(test_score, interview_score);

    const message = qualified ? 'Congratulations! You are qualified.\n\nBest regards,\nInnoHub Research Centre' : 'Sorry, you are not qualified.\n\nBest regards,\nInnoHub Research Centre';

    await sendEmailToStudent(studentId, message);
    res.status(200).json({ message: 'Email sent successfully.' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const sendEmailToStudent = async (studentId, message) => {
  try {
    const [emailResult] = await db.query('SELECT email_id FROM student_enrollment WHERE student_id = ?', [studentId]);

    if (emailResult.length === 0) {
      throw new Error('Email not found');
    }

    const email = emailResult[0].email_id;
    const transporter = nodemailer.createTransport({
      host: 'v9.cyberns.net', // Incoming Server
      port: 465, // SMTP Port
      secure: true, // Use SSL/TLS
      auth: {
        user: 'info@innohubrc.com', // Username
        pass: 'ZP1MTZr*c_cs', // Password
      },
      });
    const mailOptions = {
      from: 'info@innohubrc.com',
      to: email,
      subject: 'Exam Result',
      text: message
    };

    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
};

const createPayment = async (req, res) => {
  const { studentId } = req.params;
  const { installment1, installment2, date } = req.body;

  if (!studentId) {
    return res.status(400).json({ error: 'Student ID is required.' });
  }

  const paymentDetails = {
    installment1: installment1 || null,
    installment2: installment2 || null,
    date: date || null
  };

  try {
    await db.query('UPDATE qualified_students SET ? WHERE student_id = ?', [paymentDetails, studentId]);
    res.status(201).json({ message: 'Payment details added successfully.' });
  } catch (error) {
    console.error('Error updating payment details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const deactivateStudent = async (req, res) => {
  const studentId = parseInt(req.params.studentId); 
  console.log('Received studentId:', studentId); 

  if (isNaN(studentId)) {
    console.error('Invalid studentId:', studentId);
    return res.status(400).json({ error: 'Invalid studentId' });
  }

  try {
    const [result] = await db.query('UPDATE qualified_students SET status = 1 WHERE student_id = ?', [studentId]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }
    res.json({ message: `Student id: ${studentId} deactivated successfully` });
  } catch (error) {
    console.error('Error deactivating student:', error);
    res.status(500).json({ error: 'Error in deactivating student' });
  }
};

module.exports = { 
  createStudentMarks,
  getStudentMarks,
  getQualifiedStudents,
  sendEmail,
  createPayment,
  deactivateStudent 
};
