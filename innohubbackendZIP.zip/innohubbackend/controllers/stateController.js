const db = require('../config/dbConfig');
require('dotenv').config();
const State = require('../models/stateModel');

const getAllStates = async (req, res) => {
  try {
    const states = await State.getAll();
    res.json(states);
  } catch (error) {
    console.error('Error getting states:', error);
    res.status(500).json({ error: 'Error in getting states' });
  }
};

const getStateById = async (req, res) => {
  const stateId = req.params.stateId;

  try {
    const [result] = await db.query('SELECT * FROM states WHERE state_id = ?', [stateId]);
    res.json(result);
  } catch (error) {
    console.error('Error getting state:', error);
    res.status(500).json({ error: 'Error in getting state by id' });
  }
};

const createState = async (req, res) => {
  const { state_name, creation_date } = req.body;

  try {
    const [existingStates] = await db.query('SELECT * FROM states WHERE state_name = ?', [state_name]);
    if (existingStates.length > 0) {
      return res.status(400).json({ error: 'State name is already available, provide a new state name' });
    }

    await db.query('INSERT INTO states (state_name, creation_date, status) VALUES (?, ?, ?)', [state_name, creation_date, 0]);
    res.json({ message: 'State created successfully' });
  } catch (error) {
    console.error('Error creating state:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const updateState = async (req, res) => {
  const { stateId } = req.params;
  const updateFields = req.body;

  try {
    const [existingStates] = await db.query('SELECT * FROM states WHERE state_id = ?', [stateId]);
    if (existingStates.length === 0) {
      return res.status(404).json({ error: 'State not found.' });
    }

    const { state_name, creation_date } = updateFields;
    const updatedState = { state_name, creation_date };

    await db.query('UPDATE states SET ? WHERE state_id = ?', [updatedState, stateId]);
    
    const [updatedRows] = await db.query('SELECT * FROM states WHERE state_id = ?', [stateId]);
    const updatedStateInfo = updatedRows[0];
    
    res.status(200).json({ message: 'State updated successfully.', state: updatedStateInfo });
  } catch (error) {
    console.error('Error updating state:', error);
    res.status(500).json({ error: 'Failed to update state.' });
  }
};

const deactivateState = async (req, res) => {
  const stateId = parseInt(req.params.stateId);

  if (isNaN(stateId)) {
    console.error('Invalid stateId:', stateId);
    return res.status(400).json({ error: 'Invalid stateId' });
  }

  try {
    const [currentStatusResult] = await db.query('SELECT status FROM states WHERE state_id = ?', [stateId]);
    if (currentStatusResult.length === 0) {
      return res.status(404).json({ error: 'State not found' });
    }

    const currentStatus = currentStatusResult[0].status;
    const newStatus = currentStatus === 0 ? 1 : 0;

    const [result] = await db.query('UPDATE states SET status = ? WHERE state_id = ?', [newStatus, stateId]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'State not found' });
    }

    const message = newStatus === 1 ? `State id: ${stateId} deactivated successfully` : `State id: ${stateId} activated successfully`;
    res.json({ message });
  } catch (error) {
    console.error('Error updating state status:', error);
    res.status(500).json({ error: 'Error in updating state status' });
  }
};


module.exports = { 
  getAllStates,
  getStateById,
  createState,
  updateState,
  deactivateState
};
