const db = require('../config/dbConfig');
require('dotenv').config();
const roles = require('../models/rolesModel');

const getAllroles = async (req, res) => {
  try {
    const allRoles = await roles.getAll();
    res.json(allRoles);
  } catch (error) {
    console.error('Error getting roles:', error);
    res.status(500).json({ error: 'Error in getting roles' });
  }
};

const createRoles = async (req, res) => {
  const { roles_name, creation_date } = req.body;

  try {
    const [existingRoles] = await db.query('SELECT * FROM roles WHERE roles_name = ?', [roles_name]);
    if (existingRoles.length > 0) {
      return res.status(400).json({ error: 'Role name is already available, provide a new role name' });
    }

    await db.query('INSERT INTO roles (roles_name, creation_date, status) VALUES (?, ?, ?)', [roles_name, creation_date, 0]);
    res.json({ message: 'Role created successfully' });
  } catch (error) {
    console.error('Error creating role:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const deactivateRoles = async (req, res) => {
  const rolesId = parseInt(req.params.rolesId);

  if (isNaN(rolesId)) {
    console.error('Invalid RolesID:', rolesId);
    return res.status(400).json({ error: 'Invalid RolesID' });
  }

  try {
    const [currentStatusResult] = await db.query('SELECT status FROM roles WHERE roles_id = ?', [rolesId]);

    if (currentStatusResult.length === 0) {
      console.error(`Roles with id ${rolesId} not found`);
      return res.status(404).json({ error: 'role not found' });
    }

    const currentStatus = currentStatusResult[0].status;
    const newStatus = currentStatus === 0 ? 1 : 0; // Toggle the status

    await db.query('UPDATE roles SET status = ? WHERE roles_id = ?', [newStatus, rolesId]);
    
    const message = newStatus === 1
      ? `Roles with id ${rolesId} has been deactivated successfully`
      : `User with id ${rolesId} has been activated successfully`;

    res.json({ message });
  } catch (error) {
    console.error('Error updating roles status:', error);
    res.status(500).json({ error: 'Error updating roles status' });
  }
};

module.exports = { 
getAllroles,
createRoles,
deactivateRoles
};
