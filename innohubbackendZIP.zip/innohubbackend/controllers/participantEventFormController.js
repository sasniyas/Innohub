const Participant = require('../models/participantEventFormModel');
const Event = require('../models/eventFormModel');
const nodemailer = require('nodemailer');
const express = require('express');
const router = express.Router();

const getAllParticipants = async (req, res) => {
  try {
    const participants = await Participant.findAll();
    res.json(participants);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const getParticipantById = async (req, res) => {
  try {
    const participant = await Participant.findById(req.params.id);
    if (participant) {
      res.json(participant);
    } else {
      res.status(404).json({ error: 'Participant not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const createParticipant = async (req, res) => {
  try {
    const newParticipant = await Participant.create(req.body);
    res.json({ message: 'Participant registered successfully', id: newParticipant });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

/*const sendEmail = async (req, res) => {
  try {
    const { email, event, firstName } = req.body;

    if (!email || !firstName || !event || !event.id) {
      return res.status(400).json({ error: 'Invalid request data' });
    }

    const eventId = event.id; 
    const eventDetails = await Event.findById(eventId);

    if (!eventDetails) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const { joiningLink, joiningTime, dateOfEvent } = eventDetails;

    // Format the date to remove the time and day of the week
    const formattedDate = new Date(dateOfEvent).toLocaleDateString('en-GB', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'snipe.upl@gmail.com',
        pass: 'rekd pkdf mbfq wdnz',
      },
    });

    const mailOptions = {
      from: 'snipe.upl@gmail.com',
      to: email,
      subject: 'Join Your Event',
      html: `
        <p>Dear ${firstName},</p>
        <p>Thank you for registering for the event. You can join the meeting at ${joiningTime} on ${formattedDate} using the link below:</p>
        <p><a href="${joiningLink}">${joiningLink}</a></p>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.json({ message: 'Email sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send email' });
  }
};*/
const sendEmail = async (req, res) => {
  try {
    const { email, event, firstName } = req.body;

    if (!email || !firstName || !event || !event.id) {
      return res.status(400).json({ error: 'Invalid request data' });
    }

    const eventId = event.id; 
    const eventDetails = await Event.findById(eventId);

    if (!eventDetails) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const { eventName, joiningLink, joiningTime, dateOfEvent, eventPlatform, meetingId, passcode } = eventDetails;

    // Format the date to remove the time and day of the week
    const formattedDate = new Date(dateOfEvent).toLocaleDateString('en-GB', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const transporter = nodemailer.createTransport({
      host: 'v9.cyberns.net', // Incoming Server
      port: 465, // SMTP Port
      secure: true, // Use SSL/TLS
      auth: {
        user: 'info@innohubrc.com', // Username
        pass: 'ZP1MTZr*c_cs', // Password
      },
      });

    const mailOptions = {
      from: 'info@innohubrc.com',
      to: email,
      subject: `Confirmation and details for ${eventName} - ${formattedDate}`,
      html: `
        <p>Dear ${firstName},</p>
        <p>Thank you for registering for the <strong>${eventName}</strong> hosted by Innohub Research Center. We are excited to have you with us for this event.</p>
        <h3>Event Details are as follows</h3>
        <p><strong>Event Name:</strong> ${eventName}</p>
        <p><strong>Event Date:</strong> ${formattedDate}</p>
        <p><strong>Time:</strong> ${joiningTime}</p>
        <p><strong>Platform:</strong> ${eventPlatform}</p>
        <p><strong>Event Link:</strong> <a href="${joiningLink}">${joiningLink}</a></p>
        <p><strong>Meeting ID:</strong> ${meetingId}</p>
        <p><strong>Passcode:</strong> ${passcode}</p>
        <p>We encourage you to join us 5-10 minutes early to ensure everything works smoothly. If you have any questions or require assistance, please contact our support at <a href="mailto:support@innohub.com">support@innohub.com</a>.</p>
        <p>Best Regards,<br/>Innohub Research Center</p>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.json({ message: 'Email sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send email' });
  }
};

const updateParticipant = async (req, res) => {
  try {
    const updatedParticipant = await Participant.updateById(req.params.id, req.body);
    if (updatedParticipant) {
      res.status(200).json({ message: 'Updated successfully', participant: updatedParticipant });
    } else {
      res.status(404).json({ error: 'Participant not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

const deleteParticipant = async (req, res) => {
  try {
    const deleted = await Participant.deleteById(req.params.id);
    if (deleted) {
      res.status(200).json({ message: `Participant with id: ${req.params.id} deleted successfully` });
    } else {
      res.status(404).json({ error: 'Participant not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = {
  getAllParticipants,
  getParticipantById,
  createParticipant,
  updateParticipant,
  deleteParticipant,
  sendEmail,
};
