const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const db = require('../config/dbConfig');
const usermanagement = require('../models/usermanagementModel');
const crypto = require('crypto');
const logger = require('../loggers/logger'); // Import the logger

require('dotenv').config();

const SECRET_KEY = process.env.SECRET_KEY;

const login = async (req, res) => {
  const { username, password } = req.body;

  try {
    logger.info(`Login attempt for user: ${username}`);

    if (username === 'Superadmin' && password === 'Innohub@2024') {
      const token = jwt.sign({ id: username, role: 'Superadmin' }, SECRET_KEY, { expiresIn: '8h' });

      logger.info('Superadmin login successful');
      res.status(200).json({ message: 'Superadmin login successful', token, role: 'Superadmin' });
    } else {
      const [rows] = await db.execute('SELECT id, username, password, roles_name FROM user_credentials WHERE username = ?', [username]);

      if (!Array.isArray(rows)) {
        logger.error('Unexpected result format from database');
        throw new Error('Unexpected result format from database');
      }

      if (rows.length === 0) {
        logger.warn(`Invalid login attempt for username: ${username}`);
        return res.status(401).json({ error: 'Invalid username or password' });
      }

      const passwordMatch = await bcrypt.compare(password, rows[0].password);

      if (!passwordMatch) {
        logger.warn(`Invalid password for username: ${username}`);
        return res.status(401).json({ error: 'Invalid username or password' });
      }

      const token = jwt.sign({ id: rows[0].id, role: rows[0].roles_name }, SECRET_KEY, { expiresIn: '8h' });

      logger.info(`User ${username} logged in successfully with role ${rows[0].roles_name}`);
      res.status(200).json({ message: 'Login successful', token, role: rows[0].roles_name });
    }
  } catch (error) {
    logger.error(`Error during login for user ${username}: ${error.message}`);
    res.status(500).json({ error: 'An error occurred while processing login' });
  }
};

const grantAccess = async (req, res) => {
  const { first_name, last_name, adhaar_no, email_id, Communication_Address_line_1, dob, city, mobile_no, pincode, gender, state, roles_name, profession } = req.body;

  try {
    logger.info('Attempt to grant access');

    if (!req.admin || req.admin.id !== 'Superadmin') {
      logger.warn('Unauthorized access attempt to grantAccess');
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const username = `${first_name}`;
    const password = generateRandomPassword();
    const hashedPassword = await bcrypt.hash(password, 10);

    const userData = {
      first_name,
      last_name,
      adhaar_no,
      email_id,
      Communication_Address_line_1,
      dob,
      city,
      mobile_no,
      pincode,
      gender,
      state,
      roles_name,
      profession,
      username,
      password: hashedPassword,
    };

    await usermanagement.create(userData);

    const insertQuery = `INSERT INTO user_credentials (username, password, roles_name, email_id) VALUES (?, ?, ?, ?)`;
    await db.query(insertQuery, [username, hashedPassword, roles_name, email_id]);

    await sendEmail(first_name, email_id, password, username);

    logger.info(`Access granted for user: ${username}`);
    res.status(200).json({ message: 'User created and login credentials sent successfully.', role: roles_name });
  } catch (error) {
    logger.error(`Error granting access: ${error.message}`);
    res.status(500).json({ error: 'Internal server error' });
  }
};

const generateRandomPassword = () => {
  const length = 10;
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  return password;
};

const sendEmail = async (first_name, email_id, password, username) => {
  const transporter = nodemailer.createTransport({
    host: 'v9.cyberns.net', // Incoming Server
    port: 465, // SMTP Port
    secure: true, // Use SSL/TLS
    auth: {
      user: 'info@innohubrc.com', // Username
      pass: 'ZP1MTZr*c_cs', // Password
    },
    });

  const mailOptions = {
    from: 'info@innohubrc.com',
    to: email_id,
    subject: 'Login Credentials',
    text: `Dear ${first_name},\n\nYour login credentials are as follows:\n\nUsername: ${username}\nPassword: ${password}\n\nPlease keep these credentials safe and do not share them with anyone.\n\nBest regards,\nInnohub Research Center`,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info(`Email sent to ${email_id}`);
  } catch (error) {
    logger.error(`Failed to send email to ${email_id}: ${error.message}`);
    throw error;
  }
};

module.exports = {
  login,
  grantAccess,
};
