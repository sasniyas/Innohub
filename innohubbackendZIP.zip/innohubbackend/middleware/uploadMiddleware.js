const multer = require('multer');
const path = require('path');

// Configure storage settings for Multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');  // Directory where files will be saved
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);  // Naming convention for files
    }
});

// File filter to restrict file types
const fileFilter = (req, file, cb) => {
    // Accept image files only
    if (file.mimetype.startsWith('image/')) {
        cb(null, true);
    } else {
        cb(new Error('Invalid file type, only images are allowed!'), false);
    }
};

// Initialize upload middleware
const upload = multer({
    storage,
    limits: {
        fileSize: 1024 * 1024 * 5  // Limit file size to 5MB
    },
    fileFilter
});

module.exports = upload;
