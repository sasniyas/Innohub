const SECRET_KEY = process.env.SECRET_KEY;
const jwt = require('jsonwebtoken');

// Middleware to check if the user is logged in
const checkAuth = (req, res, next) => {

  // Get the token from the request cookies
  //const token = req.cookies.access_token;
  const token = req.headers.authorization?.split(' ')[1];

  // Check if the token exists
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    // Verify the token
    const decoded = jwt.verify(token, 'hidden');

    // Set the decoded token data on the request object
    req.user = decoded;

    // User is logged in, proceed to the next middleware/route handler
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
};


/// Middleware to check if the user is an admin
const checkAdmin = (req, res, next) => {
  // Check if the user is logged in
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if the user has the role of an admin
  db.query(
    'SELECT role_name FROM roles INNER JOIN user ON roles.role_id = User_management_details.role_name WHERE user_id = ?',
    [req.user?.user_id],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: 'Internal Server Error' });
      }
      // Check if the role exists and is 'admin'
      if (results.length === 0 || results[0]?.role_name !== 'admin') {
        return res.status(403).json({ error: 'Forbidden' });
      }

      // User is an admin, proceed to the next middleware/route handler
      next();
    }
  );
};

// Middleware to check if the user is an HR
const checkHR = (req, res, next) => {
  // Check if the user is logged in
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if the user has the role of an HR
  db.query(
    'SELECT role_name FROM roles INNER JOIN user ON roles.role_id = User_management_details.role_name WHERE user_id = ?',
    [req.user?.user_id],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: 'Internal Server Error' });
      }
      // Check if the role exists and is 'HR'
      if (results.length === 0 || results[0]?.role_name !== 'HR') {
        return res.status(403).json({ error: 'Forbidden' });
      }

      // User is an HR, proceed to the next middleware/route handler
      next();
    }
  );
};

// Middleware to check if the user has been granted access by an admin
const checkAdminAccess = (req, res, next) => {
  // Check if the user is logged in
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if the user has been granted access by an admin
  if (!req.user?.admin_granted_access) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  // User has been granted access by an admin, proceed to the next middleware/route handler
  next();
};

const authenticateAdmin = (req, res, next) => {
   const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    req.admin = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ error: 'Invalid token' });
  }
};


const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(403).json({ error: 'No token provided' });
  }

  const token = authHeader.split(' ')[1]; // Extract the token from "Bearer <token>"

  if (!token) {
    return res.status(403).json({ error: 'No token provided' });
  }

  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
      console.error('Token verification error:', err); // Log the error for debugging
      return res.status(500).json({ error: 'Failed to authenticate token' });
    }

    req.admin = decoded; // Attach the decoded token (which contains the admin id) to the request object
    next();
  });
};

const verifyResetToken = (req, res, next) => {
  const resetToken = req.headers.authorization?.split(' ')[1];
  if (!resetToken) {
    return res.status(403).json({ error: 'No reset token provided' });
  }
  jwt.verify(resetToken, SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(400).json({ error: 'Invalid or expired reset token' });
    }
    req.email_id = decoded.email_id;
    next();
  });
};

// Middleware to check if the user has a specific role

// const checkRole = (role) => {
//   return async (req, res, next) => {
//     if (!req.user) {
//       return res.status(401).json({ error: 'Unauthorized' });
//     }

//     const userRoles = await User.getUserRoles(req.user.user_id);

//     if (!userRoles.some(userRole => userRole.role_name === role)) {
//       return res.status(403).json({ error: 'Forbidden' });
//     }

//     next();
//   };
// };

const checkRole = (role) => {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const userRoles = await User.getUserRoles(req.user.user_id);

    if (!userRoles.some(userRole => userRole.role_name === role)) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    next();
  };
};

// Middleware to check permissions
const checkPermissions = (resource, action) => {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const userRoles = await User.getUserRoles(req.user.user_id);
    const roleIds = userRoles.map(role => role.role_id);

    const permissions = await Promise.all(
      roleIds.map(roleId => rolespermission.getPermissionsByRoleId(roleId))
    );

    const flatPermissions = permissions.flat();

    const hasAccess = flatPermissions.some(permission =>
      permission.resource === resource && permission.action === action
    );

    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }

    next();
  };
};

// Usage in routes
// app.get('/admin-endpoint', checkAuth, checkRole('admin'), (req, res) => {
//   res.json({ message: 'Welcome, admin!' });
// });

// app.post('/resource-endpoint', checkAuth, checkPermissions('resource', 'create'), (req, res) => {
//   res.json({ message: 'Resource created!' });
// });

// module.exports = {
//   checkAuth,
  
//   // other exports
// };


module.exports = {
  checkAuth,
  checkAdmin,
  checkHR,
  checkAdminAccess,
  authenticateAdmin,
  verifyToken,
  verifyResetToken,
  checkRole,
  checkPermissions,
};
