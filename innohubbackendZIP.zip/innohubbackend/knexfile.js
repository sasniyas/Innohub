// Update with your config settings.
require("dotenv").config()
/**
 * @type { Object.<string, import("knex").Knex.Config> }
 */
// const fs = require('fs');
// const caCert = fs.readFileSync('/root/ars_develop-ca-certificate.crt');
// const tlsOptions = {
//     ca: [caCert], // Specify the CA certificate(s)
//   };

module.exports = {

  development: {
    client: 'mysql2',
    connection: {
      // filename: './models/database.js'
      host: process.env.MYSQL_HOST ,
      user: process.env.MYSQL_USER || 'root',
      password: process.env.MYSQL_PWD || 'Mysql@password',
      database: process.env.MYSQL_DB || 'inno_hub',
    }
  },

  staging: {
    client: 'mysql2',
    connection: {
      database: process.env.MYSQL_DB,
      user: process.env.MYSQL_USER,
      password: process.env.MYSQL_PWD
    },
    pool: {
      min: process.env.MYSQL_MIN_LIMIT,
      max: process.env.MYSQL_MAX_LIMIT
    },
    migrations: {
      tableName: 'knex_migrations'
    }
  },

  // production: {
  //   client: 'mysql2',
  //   connection: {
  //     host: 'lin-10471-6470-mysql-primary.servers.linodedb.net',
  //     user: 'linroot',
  //     port: 3306,
  //     password: 'Z81M7Wcqu2qB@cUM',
  //     database: 'upl_app',
  //     ssl: tlsOptions,
  //   },
  //   pool: {
  //     min: 2,
  //     max: 10
  //   },
  //   migrations: {
  //     tableName: 'knex_migrations'
  //   }
  // }

};
