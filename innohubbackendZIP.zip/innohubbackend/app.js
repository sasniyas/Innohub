const express = require('express');
const path = require('path');
const cors = require('cors')
const app = express();
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
require('dotenv').config();


// Middleware for parsing JSON
app.use(cookieParser());
app.use(bodyParser.json());
// while deployment enable this and disable localhost
// app.use(cors({credentials: true, origin: 'http://uplrc.com'}));     

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

app.use(express.json());

//Import Routes

const enrolledMailRoutes = require('./routes/enrolledMailRoutes.js');
const stateRoutes = require('./routes/stateRoutes.js');
const cityRoutes = require('./routes/cityRoutes.js');
const higherEducationRoutes = require('./routes/higherEducationRoutes.js');
const studentEnrollmentRoutes = require('./routes/studentEnrollmentRoutes.js');
const superAdminLoginRoutes = require('./routes/superAdminLoginRoutes.js');
const usermanagementRoutes = require('./routes/usermanagementRoutes.js');
const rolesRoutes = require('./routes/rolesRoutes.js');
const markRoutes = require('./routes/markRoutes.js');
const queryemailRoutes = require('./routes/queryemailRoutes.js');
const eventFormRoutes = require('./routes/eventFormRoutes.js')
// const uploadRoutes = require('./routes/uploadRoutes.js')
const participantEventFormRoutes = require('./routes/participantEventFormRoutes.js');
const forgotpasswordRoutes = require('./routes/forgotpasswordRoutes.js');
const accessRoutes =require('./routes/accessRoutes.js')
// Use routes

app.use('/api/enrollMail', enrolledMailRoutes);
app.use('/api/state', stateRoutes);
app.use('/api/city', cityRoutes);
app.use('/api/degree', higherEducationRoutes);
app.use('/api/students', studentEnrollmentRoutes);
app.use('/api', superAdminLoginRoutes);
app.use('/api/usermanage', usermanagementRoutes);
//console.log('Registering routes...', /api/usermanage);
app.use('/api/roles', rolesRoutes);
app.use('/api/marks', markRoutes);
app.use('/api/mail', queryemailRoutes);
app.use('/api/events', eventFormRoutes);
//app.use('/api/upload', uploadRoutes);
app.use('/api/participantseventform', participantEventFormRoutes);
app.use('/api/password', forgotpasswordRoutes);
// Ensure uploads directory exists
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/access',accessRoutes);

// Start the server
app.listen(8000, () => {
  console.log('server running')
})
//for cloud
// app.listen(8000, '192.46.214.107', () => {
//     console.log('server running');
//   });
