const mysql = require('mysql2/promise');
const dotenv=require('dotenv');
const tls = require('tls');
dotenv.config();
const fs = require('fs');

// Read the CA certificate file
//const caCert = fs.readFileSync('/root/ars_develop-ca-certificate.crt');

// Create a TLS connection options object
/* const tlsOptions = {
    ca: [caCert], // Specify the CA certificate(s)
  }; */

const pool=mysql.createPool({
    
// For Local //

    // connectionLimit: process.env.MYSQL_LIMIT,
    host: 'localhost',
    //port: 3306,
    user: 'root',
    password: 'Mysql@password',
    database: 'inno_hub',

// For QA cloud //

//     connectionLimit: process.env.MYSQL_LIMIT,
    // host: 'lin-10471-6470-mysql-primary.servers.linodedb.net',
    // user: 'linroot',
    // port: 3306,
    // password: 'Z81M7Wcqu2qB@cUM',
    // database: 'upl_app',
    // ssl: tlsOptions,
    // connectTimeout: 15000  
});

// cloud DB Connection Test //

// pool.query('SELECT * FROM program', (error, results) => {
//     if (error) {
//       console.error(error);
//       return;
//     }
//     console.log(results);
//     // pool.end(); // Close the connection pool
//   });
module.exports = pool;