const express = require('express');
const router = express.Router();
const studentsEnrollmentController = require('../controllers/studentsEnrollmentController');
// const knex = require('../knexfile'); // Import your Knex instance

router.get('/count', studentsEnrollmentController.getAllStudentsCount);
router.get('/', studentsEnrollmentController.getAllStudents);
router.get('/:id', studentsEnrollmentController.getStudentById);
router.post('/', studentsEnrollmentController.createStudentEnrollment);
router.put('/:studentId', studentsEnrollmentController.updateStudent);
router.delete('/:studentId', studentsEnrollmentController.deleteStudent);
router.put('/:studentId/deactivate', studentsEnrollmentController.deactivateStudent);


module.exports = router;
