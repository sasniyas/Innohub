const express = require('express');
const forgotpasswordController = require('../controllers/forgotpasswordController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', forgotpasswordController.SendingOTP);
router.post('/otp', authMiddleware.verifyResetToken, forgotpasswordController.VerifyOTP);
router.post('/resend', authMiddleware.verifyResetToken, forgotpasswordController.ResendOtp);
router.post('/updatepassword', authMiddleware.verifyResetToken, forgotpasswordController.ResetPassword);

module.exports = router;
