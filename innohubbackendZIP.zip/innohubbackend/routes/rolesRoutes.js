const express = require('express');
const router = express.Router();
const rolesController = require('../controllers/rolesController');

router.get('/', rolesController.getAllroles);
router.post('/', rolesController.createRoles);
//router.put('/:rolesId/deactivate', rolesController.deactivateRoles);
router.delete('/:rolesId/deactivate', rolesController.deactivateRoles);


module.exports = router;
