const express = require('express');
const superAdminController = require('../controllers/superAdminController');
const { verifyToken } = require('../middleware/authMiddleware');

const router = express.Router();

// Login route
router.post('/login', superAdminController.login);

// POST route to grant access to HR or admin by super admin
router.post('/grant-access', verifyToken, superAdminController.grantAccess);




module.exports = router;
