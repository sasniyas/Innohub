// const express = require('express');
// const router = express.Router();
// const rolesController=require('../controllers/rolesController');
// const accessController=require('../controllers/accessController');

// router.get('/', rolesController.getAllroles);
// router.post('/assignpermission', accessController.access);



// module.exports = router;


const express = require('express');
const router = express.Router();
const rolesController = require('../controllers/rolesController');
const accessController = require('../controllers/accessController');
const { checkAuth, checkRole } = require('../middleware/authMiddleware'); // Adjust the path as needed

// const { checkAuth } = require('../middleware/authMiddleware'); // Adjust the path as needed
// const {authorize}=require('../middleware/authMiddleware');
// const checkUserRole=require('../controllers/accessController');

// Get all roles - protected route
router.get('/',checkAuth, rolesController.getAllroles);

// Assign permissions to a role - protected route
// router.post('/assignpermission', accessController.access);
router.post('/assignpermission', checkAuth, checkRole('admin'), accessController.access);


module.exports = router;
