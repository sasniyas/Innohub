// routes/eventRoutes.js

const express = require('express');
const router = express.Router();
const eventFormController = require('../controllers/eventFormController')

router.get('/', eventFormController.getAllEvents);
router.get('/:id', eventFormController.getEventById);
router.post('/', eventFormController.createEvent);
router.put('/:id', eventFormController.updateEvent);
router.delete('/:id', eventFormController.deleteEvent);

module.exports = router;
