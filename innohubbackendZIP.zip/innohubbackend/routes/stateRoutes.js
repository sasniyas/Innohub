const express = require('express');
const router = express.Router();
const stateController = require('../controllers/stateController');

router.get('/', stateController.getAllStates);
router.get('/:stateId', stateController.getStateById);
router.post('/', stateController.createState);
router.put('/:stateId', stateController.updateState);
router.put('/:stateId/deactivate', stateController.deactivateState);

module.exports = router;
