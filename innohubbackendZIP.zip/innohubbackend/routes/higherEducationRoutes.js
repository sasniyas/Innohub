const express = require('express');
const router = express.Router();
const higherEducationController = require('../controllers/higherEducationController');

router.get('/', higherEducationController.getAllDegrees);
router.get('/:degreeId', higherEducationController.getDegreesById);
router.post('/', higherEducationController.createDegrees);
router.put('/:degreeId', higherEducationController.updateDegrees);
router.put('/:degreeId/deactivate', higherEducationController.deactivateDegrees);

module.exports = router;
