const express = require('express');
const router = express.Router();
const markController = require('../controllers/markController');

router.get('/qualified', markController.getQualifiedStudents);
router.post('/', markController.createStudentMarks);
router.get('/', markController.getStudentMarks);
router.post('/:studentId',markController.sendEmail);
router.post('/:studentId/payment', markController.createPayment);
router.put('/:studentId/deactivate', markController.deactivateStudent);

module.exports = router;