const express = require('express');
const router = express.Router();
//Import the required controllers
const userController= require('../controllers/userController.js');
const authMiddleware = require('../middleware/authMiddleware.js');

router.get('/statusList', userController.getStatusList);
router.put('/:userId/status', authMiddleware.checkAuth,  authMiddleware.checkAdmin, userController.updateUserStatus);

module.exports = router;
