const express = require('express');
const router = express.Router();
const queryemailController = require('../controllers/queryemailController');

router.post('/', queryemailController.sendMail);

module.exports = router;