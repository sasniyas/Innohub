const express = require('express');
const router = express.Router();
const usermanagementController=require('../controllers/usermanagementController');
// const knex = require('../knexfile');
const authMiddleware = require("../middleware/authMiddleware")
const upload = require("../middleware/uploadMiddleware")

router.get('/',usermanagementController.getAllusermanagement);

router.get('/:user_id',usermanagementController.getusermanagementByuser_id);

router.post('/create', usermanagementController.createusermanagement);
router.put('/:user_id', usermanagementController.updateusermanagement);
router.delete('/:user_id', usermanagementController.deleteusermanagement);
// router.put('/:user_id/deactivate', usermanagementController.deactivateusermanagement);
router.put('/updateprofile/:user_id', authMiddleware.checkAuth, upload.single('photo'), usermanagementController.updateUserProfile);
router.put('/updatepassword/:user_id', authMiddleware.checkAuth, usermanagementController.updatePassword);

router.post('/logout', authMiddleware.checkAuth, usermanagementController.logout);


module.exports= router;