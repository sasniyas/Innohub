const express = require('express');
const router = express.Router();
const cityController = require('../controllers/cityController');

router.get('/:stateId', cityController.getCitiesByState);
router.get('/:cityId/city', cityController.getCitiesById);
router.get('/', cityController.getAllCities);
router.post('/', cityController.createCities);
router.put('/:cityId/city', cityController.updateCities);
router.put('/:cityId/deactivate', cityController.deactivateCities);

module.exports = router;
