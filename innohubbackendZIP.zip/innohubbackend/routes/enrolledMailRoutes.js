const express = require('express');
const router = express.Router();
const enrolledMailController = require('../controllers/enrolledMailController');

// Route to handle form submission and enrollment
router.post('/', enrolledMailController.enrolledMail);

module.exports = router;
