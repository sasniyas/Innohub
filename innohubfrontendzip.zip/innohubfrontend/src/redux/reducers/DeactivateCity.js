import { ActionTypes } from "../constants/action-types";

const initialState = {
  cities: [],
};

const DeactivateCity = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionTypes.DEACTIVATE_EDUCATION_SUCCESS:
      return {
        ...state,
        cities: state.cities.map((state) =>
          state.state_id === payload.stateId ? { ...state, status: payload.newStatus } : state
        ),
      };
    default:
      return state;
  }
};

export default DeactivateCity;
