// import React from "react";
// import Footer from "../Footer";
// import Header from "../Header";

// const Eventdetails = () => {
//   return (
//     <div className="relative bg-gray xl:w-full lg:w-[1000px] md:w-[1180px] w-[749px] px-0 mx-auto overflow-hidden">
//       <div className="relative mx-auto pt-40 font-poppins">
//         <Header />
//         <div className="relative h-screen w-screen">
//         <img src="Desktop - 2.png" alt="Event details" className="w-full h-full object-cover absolute inset-0 z-0 -ml-10 mt-[-65px]" />
       
//         </div>
//         <Footer />
//       </div>
//     </div>
//   );
// };

// export default Eventdetails;


// import React from "react";
// import Footer from "../Footer";
// import Header from "../Header";

// const Eventdetails = ({ heading, subtitle }) => {
//   return (
//     <div className="relative bg-gray xl:w-full lg:w-[1000px] md:w-[1180px] w-[749px] px-0 mx-auto overflow-hidden">
//       <div className="relative mx-auto pt-40 font-poppins">
//         <Header />
//         <div className="relative h-screen w-screen">
//           <img src="Desktop - 2.png" alt="Event details" className="w-full h-full object-cover absolute inset-0 z-0 -ml-10 mt-[-65px]" />
//         </div>
//         <div className="text-center my-8">
//           <h1 className="text-3xl font-bold">{heading}</h1>
//           {subtitle && <h2 className="text-xl text-gray-600">{subtitle}</h2>}
//         </div>
//         <Footer />
//       </div>
//     </div>
//   );
// };

// export default Eventdetails;


import React from "react";
import Footer from "../Footer";
import Header from "../Header";

const Eventdetails = ({ hello, subtitle }) => {
  return (
    <div className="relative bg-gray xl:w-full lg:w-[1000px] md:w-[1180px] w-[749px] px-0 mx-auto overflow-hidden">
      <div className="relative mx-auto pt-40 font-poppins">
        <Header />
        <div className="relative h-screen w-screen">
          <img 
            src="Desktop - 2.png" 
            alt="Event details" 
            className="w-full h-full object-cover absolute inset-0 z-0 -ml-10 mt-[-65px]" 
          />
        </div>
        <div className="relative z-10 text-center my-4 pt-4"> {/* Add z-10 to bring it above the image */}
          <h1 className="text-3xl font-bold  text-white absolute left-10">{hello}</h1>
          {subtitle && <h2 className="text-xl text-gray-600">{subtitle}</h2>}
        </div>
        <Footer />
      </div>
    </div>
  );
};

export default Eventdetails;
