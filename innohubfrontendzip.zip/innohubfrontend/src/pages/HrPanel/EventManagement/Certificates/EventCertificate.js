import React from 'react';

const EventCertificate = () => {
  return (
    <div>
      <h2>Certificates</h2>
      <p className='text-cold-grey-white'>Here are some of the certificates I have received</p>
      {/* Certificates content here */}
    </div>
  );
};

export default EventCertificate;
